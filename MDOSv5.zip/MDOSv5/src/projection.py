# src/projection.py

class ProjectionEngine:
    """
    Owns the rebuild cycle for all ledgers and reports.
    """

    def __init__(self, orchestrator):
        self.o = orchestrator

    def rebuild_all(self):
        events = self.o.log.events

        # Ledgers
        self.o.cash_ledger.rebuild(events)
        self.o.accrual_ledger.rebuild(events)
        self.o.inventory_ledger.rebuild(events)
        self.o.fund_ledger.rebuild(events)
        self.o.budget_ledger.rebuild(events)
        self.o.grant_ledger.rebuild(events)
        self.o.project_ledger.rebuild(events)

        # Reports
        self.o.ar_aging.rebuild(events)
        self.o.ap_aging.rebuild(events)
        self.o.pnl.rebuild(events)
        self.o.balance_sheet.rebuild(events)
        self.o.cash_flow.rebuild(events)
