# renal_assessment.py
# MDOS Renal Assessment Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

RENAL_ASSESSMENT_SCHEMAS = {
    "RenalAssessmentPerformed": {
        "required": [
            "patient_id",
            "timestamp",
            "performed_by",
        ],
        "optional": [
            "hydration_status",        # dry, normal, overloaded
            "urine_output_ml_per_hr",
            "urine_characteristics",   # color, clarity, sediment
            "costovertebral_angle_tenderness",
            "bladder_distention",
            "edema",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestRenalAssessmentProjection:
    """
    patient_id → latest renal assessment snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "RenalAssessmentPerformed":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "performed_by": event["performed_by"],
        }

        for key in [
            "hydration_status",
            "urine_output_ml_per_hr",
            "urine_characteristics",
            "costovertebral_angle_tenderness",
            "bladder_distention",
            "edema",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class RenalAssessmentHistoryProjection:
    """
    patient_id → list of renal assessments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "RenalAssessmentPerformed":
            pid = event["patient_id"]
            self.state[pid].append(event)
