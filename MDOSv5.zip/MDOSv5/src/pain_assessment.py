# pain_assessment.py
# MDOS Pain Assessment Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

PAIN_ASSESSMENT_SCHEMAS = {
    "PainScoreRecorded": {
        "required": [
            "patient_id",
            "timestamp",
            "recorded_by",
            "score",
        ],
        "optional": ["location", "character", "duration", "notes"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestPainScoreProjection:
    """
    patient_id → latest pain score snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "PainScoreRecorded":
            return

        pid = event["patient_id"]

        self.state[pid] = {
            "score": event["score"],
            "location": event.get("location"),
            "character": event.get("character"),
            "duration": event.get("duration"),
            "timestamp": event["timestamp"],
            "recorded_by": event["recorded_by"],
            "notes": event.get("notes"),
        }


class PainScoreHistoryProjection:
    """
    patient_id → list of pain score events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "PainScoreRecorded":
            pid = event["patient_id"]
            self.state[pid].append(event)
