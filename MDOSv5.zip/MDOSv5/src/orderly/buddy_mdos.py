# src/orderly/buddy_mdos.py
# MDOS Buddy — crash‑proof constitutional REPL

import json
from typing import Any, Dict

from .terminal_ui import render_terminal
from .command_registry import CommandRegistry

registry = CommandRegistry()


# ---------------------------------------------------------------------------
# Crash‑proof wrapper for all module calls
# ---------------------------------------------------------------------------

def safe_call(handler, world):
    """
    Execute a module handler safely.
    No module can crash the buddy.
    """
    try:
        handler(world)
    except Exception as e:
        print(f"\n[MODULE ERROR] {e}\n")
        input("Press Enter to continue...")


# ---------------------------------------------------------------------------
# Load commands from modules (autodiscovery)
# ---------------------------------------------------------------------------

def load_commands_from_modules(world):
    """
    Ask each module if it has register_commands(registry).
    If not, infer commands based on filename and function names.
    Crash‑proof: no module can break loading.
    """

    for module in world.modules:

        # 1. Explicit registration
        try:
            if hasattr(module, "register_commands"):
                module.register_commands(registry)
                continue
        except Exception as e:
            print(f"[COMMAND REGISTRATION ERROR] {module.__name__}: {e}")
            continue

        # 2. Infer command name from filename
        name = module.__name__.split(".")[-1]
        cmd = None

        try:
            if name.endswith("_assessment"):
                cmd = name.replace("_assessment", "")

                fn_name = f"run_{cmd}_form"
                if hasattr(module, fn_name):
                    registry.register(
                        name=cmd,
                        handler=getattr(module, fn_name),
                        help_text=f"Enter a {cmd} assessment",
                        category="clinical",
                    )
        except Exception as e:
            print(f"[INFERRED COMMAND ERROR] {module.__name__}: {e}")

        # 3. Infer history commands
        try:
            if cmd:
                hist_fn = f"show_{cmd}_history"
                if hasattr(module, hist_fn):
                    registry.register(
                        name=f"{cmd}-history",
                        handler=getattr(module, hist_fn),
                        help_text=f"Show {cmd} assessment history",
                        category="clinical",
                    )
        except Exception as e:
            print(f"[HISTORY COMMAND ERROR] {module.__name__}: {e}")


# ---------------------------------------------------------------------------
# Built‑in commands
# ---------------------------------------------------------------------------

def print_banner():
    print("\nMDOS — Constitutional Buddy")
    print("---------------------------")
    print("Type 'commands' to see all available commands.\n")


def interactive_genesis(world):
    """
    Crash‑proof patient genesis form.
    """
    try:
        print("\n--- Patient Genesis Form ---")
        pid = input("Patient ID: ").strip()
        name = input("Name: ").strip()
        dob = input("DOB (YYYY-MM-DD): ").strip()
        created_by = input("Created by: ").strip()

        extra = {}
        for field in [
            "sex",
            "gender_identity",
            "pronouns",
            "contact_phone",
            "contact_email",
            "address",
            "notes",
        ]:
            val = input(f"{field} (optional): ").strip()
            if val:
                extra[field] = val

        from .patient_genesis import build_patient_genesis_event
        event = build_patient_genesis_event(
            patient_id=pid,
            name=name,
            dob=dob,
            created_by=created_by,
            **extra,
        )

        print("\nGenerated event:")
        print(json.dumps(event, indent=2))

        confirm = input("Append to event log? (y/n): ").strip().lower()
        if confirm == "y":
            world.append(event)
            print("Event appended.\n")
        else:
            print("Cancelled.\n")

    except Exception as e:
        print(f"[GENESIS ERROR] {e}")


registry.register(
    name="genesis",
    handler=interactive_genesis,
    help_text="Create a new patient",
    category="system",
)


def list_patients(world):
    try:
        directory = world.projections.get_state().get("patient_directory", {})
        if not directory:
            print("\nNo patients found.\n")
            input("Press Enter to continue...")
            return

        print("\n--- Patient List ---")
        for pid, patient in directory.items():
            print(f" {pid}  →  {patient.get('name')}  (DOB: {patient.get('dob')})")
        print("")
        input("Press Enter to continue...")

    except Exception as e:
        print(f"[PATIENT LIST ERROR] {e}")
        input("Press Enter to continue...")


registry.register(
    name="patients",
    handler=list_patients,
    help_text="List all patients",
    category="system",
)


def show_commands(world):
    try:
        print("\n--- Available Commands ---")
        cmds = registry.get_all()
        for name, meta in cmds.items():
            print(f"  {name:<20} {meta['help']}")
        print("")
        input("Press Enter to continue...")

    except Exception as e:
        print(f"[COMMAND LIST ERROR] {e}")
        input("Press Enter to continue...")


registry.register(
    name="commands",
    handler=show_commands,
    help_text="Show all commands",
    category="system",
)


def open_projection(world, pid):
    try:
        directory = world.projections.get_state().get("patient_directory", {})
        patient = directory.get(pid)

        if not patient:
            print(f"No patient with ID {pid}")
            return

        from .patient_snapshot import build_patient_snapshot
        from .html_renderer import render_patient_page

        snapshot = build_patient_snapshot(world, pid)
        render_patient_page(snapshot)


    except Exception as e:
        print(f"[PROJECTION ERROR] {e}")


# ---------------------------------------------------------------------------
# Main REPL — crash‑proof
# ---------------------------------------------------------------------------

def run(world):
    """
    Crash‑proof REPL.
    Nothing the user types can kill it.
    Nothing a module does can kill it.
    """

    print_banner()

    # Load module commands safely
    try:
        load_commands_from_modules(world)
    except Exception as e:
        print(f"[COMMAND LOAD ERROR] {e}")

    while True:
        try:
            render_terminal(world)
        except Exception as e:
            print(f"[UI ERROR] {e}")

        raw = input("> ").strip()
        if not raw:
            continue

        cmd = raw.lower()

        # Quit
        if cmd in ("quit", "exit", "q"):
            print("Goodbye.")
            break

        # Projection HTML
        if cmd.startswith("projection "):
            pid = cmd.split(" ", 1)[1].strip()
            safe_call(lambda w: open_projection(w, pid), world)
            continue

        # State
        if cmd == "state":
            try:
                state = world.projections.get_state()
                print(json.dumps(state, indent=2, default=str))
            except Exception as e:
                print(f"[STATE ERROR] {e}")
            input("Press Enter to continue...")
            continue

        # Reload
        if cmd == "reload":
            try:
                world.rebuild()
                print("Projections rebuilt.")
            except Exception as e:
                print(f"[REBUILD ERROR] {e}")
            input("Press Enter to continue...")
            continue

        # Command registry dispatch
        handler = registry.resolve(cmd)
        if handler:
            safe_call(handler, world)
            continue

        # Raw JSON event
        try:
            event = json.loads(raw)
        except json.JSONDecodeError as e:
            print(f"[!] Invalid JSON: {e}")
            input("Press Enter to continue...")
            continue

        etype = event.get("type", "")
        if not (etype.startswith(("Consent", "System")) or event.get("consent_given", False)):
            print('[!] Consent missing — add "consent_given": true')
            input("Press Enter to continue...")
            continue

        try:
            world.append(event)
            print("Event appended.")
        except Exception as e:
            print(f"[APPEND ERROR] {e}")

        input("Press Enter to continue...")
