# src/rules.py

class RuleEngine:
    """
    Minimal rule engine organ.
    Supports:
      - registering rules
      - evaluating rules after each event
      - condition → action automation
    """

    def __init__(self):
        self.rules = []  # list of {"condition": fn, "action": fn, "name": str}

    def add_rule(self, name, condition, action):
        self.rules.append({
            "name": name,
            "condition": condition,
            "action": action
        })
        print(f"Rule added: {name}")

    def evaluate_rules(self):
        """
        Called after each event is recorded.
        """
        for rule in self.rules:
            try:
                if rule["condition"]():
                    print(f"Rule triggered: {rule['name']}")
                    rule["action"]()
            except Exception as e:
                print(f"Rule error ({rule['name']}): {e}")
                self._machine_event("rule_error", str(e))
