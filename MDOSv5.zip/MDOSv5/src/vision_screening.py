# vision_screening.py
# MDOS Vision Screening Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

VISION_SCREENING_SCHEMAS = {
    "VisionScreeningPerformed": {
        "required": [
            "patient_id",
            "timestamp",
            "performed_by",
        ],
        "optional": [
            "visual_acuity_left",
            "visual_acuity_right",
            "intraocular_pressure_left",
            "intraocular_pressure_right",
            "color_vision_result",
            "glaucoma_risk",
            "cataract_findings",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestVisionScreeningProjection:
    """
    patient_id → latest vision screening snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "VisionScreeningPerformed":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "performed_by": event["performed_by"],
        }

        for key in [
            "visual_acuity_left",
            "visual_acuity_right",
            "intraocular_pressure_left",
            "intraocular_pressure_right",
            "color_vision_result",
            "glaucoma_risk",
            "cataract_findings",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class VisionScreeningHistoryProjection:
    """
    patient_id → list of vision screening events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "VisionScreeningPerformed":
            pid = event["patient_id"]
            self.state[pid].append(event)
