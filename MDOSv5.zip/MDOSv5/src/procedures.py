# procedures.py
# MDOS Procedure Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

PROCEDURE_SCHEMAS = {
    "ProcedurePerformed": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "performed_by",
            "procedure_code",
        ],
        "optional": ["notes"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class ProcedureHistoryProjection:
    """
    patient_id → list of all procedures performed
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event.get("type") == "ProcedurePerformed":
            pid = event["patient_id"]
            self.state[pid].append(event)
