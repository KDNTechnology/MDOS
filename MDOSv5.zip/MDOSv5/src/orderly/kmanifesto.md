# cx-I-010: I. PURPOSE OF THIS WORLD
This World exists to operate on causal truth
All state must be derived from events
All decisions must be deterministic and replayable
All evolution of the World must be governed by explicit laws
This World SHALL NOT rely on hidden state, mutable memory, or implicit interpretation.


# cx-I-020: II. PRIMACY OF EVENTS
Events are the only source of truth
Events are immutable once appended
Events must be causally ordered
Events must be sufficient to reconstruct all derived state
If a fact is not represented as an event, it SHALL NOT be treated as having occurred.


# cx-I-030: III. DETERMINISTIC POLICIES
Policies must be pure functions
Policies must produce identical outputs for identical histories
Policies must be versioned and auditable
Policies must never bypass the event log
Policies SHALL NOT depend on randomness, external state, or unlogged computation.


# cx-I-040: IV. PROJECTIONS AS OBSERVABLES
Projections must be derived solely from events
Projections must be rebuildable by replay
Projections must never store authoritative truth
Projections must reflect the World’s causal history
Projections are measurements, not truth.


# cx-I-050: V. THE ROLE OF THE AI PARTICIPANT
The AI is a proposer, not an executor
The AI may propose schemas, policies, projections, and improvements
The AI may not modify logs, execute code, or alter physics
All AI proposals must be logged as events
The AI SHALL operate under the laws of this Manifesto at all times.


# cx-I-060: VI. VALIDATION AND SAFETY
All proposals must be validated before acceptance
Validation must be deterministic and reproducible
Rejected proposals must be logged with reasons
No unvalidated change may affect the World
Safety takes precedence over autonomy.


# cx-I-070: VII. SIMULATION AND COUNTERFACTUALS
All changes must be tested in Simulation Worlds
Simulation Worlds must share physics with the parent World
Simulation results must be logged and reviewable
Only validated simulations may lead to upgrades
Simulation is the mechanism of foresight.


# cx-I-080: VIII. WORLD EVOLUTION
Upgrades must be explicit events
Upgrades must include rationale and simulation evidence
Upgrades must never rewrite history
Upgrades must preserve replayability
The World evolves through lawful, logged, validated change.


# cx-I-090: IX. HUMAN OVERSIGHT
Humans retain final authority over irreversible actions
Human approvals must be logged as events
Humans may suspend policies via explicit events
Humans may create new governance clauses through events
Human agency is preserved through explicit governance.


# cx-I-100: X. META-GOVERNANCE
This Manifesto is itself part of the event history
Changes to this Manifesto must be explicit governance events
No clause may be altered without simulation and validation
Event integrity takes precedence over convenience
The laws of the World evolve only through transparent, causal processes.
