# src/plugins.py

import os
import importlib

class PluginSystem:
    """
    Plugin organ.
    Dynamically loads Python modules from src/plugins/.
    Plugins may:
      - register commands
      - extend ledgers
      - add MI proposal types
      - add dashboards
      - add event processors
    """

    PLUGIN_DIR = "src/plugins"

    def load_plugins(self):
        print("Loading plugins...")

        if not os.path.exists(self.PLUGIN_DIR):
            os.makedirs(self.PLUGIN_DIR)
            print("Created plugin directory.")
            return

        for filename in os.listdir(self.PLUGIN_DIR):
            if not filename.endswith(".py"):
                continue

            module_name = filename[:-3]
            module_path = f"src.plugins.{module_name}"

            try:
                module = importlib.import_module(module_path)
                if hasattr(module, "register"):
                    module.register(self)
                    print(f"Loaded plugin: {module_name}")
                else:
                    print(f"Plugin {module_name} has no register() function")
            except Exception as e:
                print(f"Failed to load plugin {module_name}: {e}")

        print("Plugin loading complete.\n")
