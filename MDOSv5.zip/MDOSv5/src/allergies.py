# allergies.py
# MDOS Allergy Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

ALLERGY_SCHEMAS = {
    "AllergyAdded": {
        "required": [
            "patient_id",
            "timestamp",
            "added_by",
            "substance",
        ],
        "optional": ["reaction", "severity", "notes"],
    },

    "AllergyRemoved": {
        "required": [
            "patient_id",
            "timestamp",
            "removed_by",
            "substance",
        ],
        "optional": ["reason"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class ActiveAllergiesProjection:
    """
    patient_id → { substance → details }
    """

    def __init__(self):
        self.state = defaultdict(dict)

    def apply(self, event: Dict[str, Any]):
        et = event["type"]
        pid = event["patient_id"]

        if et == "AllergyAdded":
            sub = event["substance"]
            self.state[pid][sub] = {
                "reaction": event.get("reaction"),
                "severity": event.get("severity"),
                "timestamp": event["timestamp"],
                "added_by": event["added_by"],
            }

        elif et == "AllergyRemoved":
            sub = event["substance"]
            if sub in self.state[pid]:
                del self.state[pid][sub]


class AllergyHistoryProjection:
    """
    patient_id → list of allergy events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] in ("AllergyAdded", "AllergyRemoved"):
            pid = event["patient_id"]
            self.state[pid].append(event)
