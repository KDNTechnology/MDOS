# src/orderly/modules/optional_vitals.py
# MDOS Optional Vitals Module — crash‑proof, payload‑aware

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Safe helpers
# ---------------------------------------------------------------------------

def safe_float(val):
    try:
        return float(val)
    except:
        return None


# ---------------------------------------------------------------------------
# Event Schema
# ---------------------------------------------------------------------------

OPTIONAL_VITALS_SCHEMA = {
    "required": [
        "patient_id",
        "timestamp",
        "performed_by",
    ],
    "optional": [
        "height_cm",
        "height_in",
        "weight_kg",
        "weight_lb",
        "bmi",
        "waist_circumference_cm",
        "waist_circumference_in",
        "head_circumference_cm",
        "head_circumference_in",
        "notes",
    ],
}


# ---------------------------------------------------------------------------
# Projections (payload‑aware)
# ---------------------------------------------------------------------------

class LatestOptionalVitalsProjection:
    """
    patient_id → latest optional vitals snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        try:
            if event["type"] != "OptionalVitalsRecorded":
                return

            payload = event.get("payload", {})
            pid = payload.get("patient_id")
            if not pid:
                return

            snapshot = {
                "timestamp": payload.get("timestamp"),
                "performed_by": payload.get("performed_by"),
            }

            for key in OPTIONAL_VITALS_SCHEMA["optional"]:
                if key in payload:
                    snapshot[key] = payload[key]

            self.state[pid] = snapshot

        except Exception as e:
            print(f"[OPTIONAL VITALS PROJECTION ERROR] {e}")


class OptionalVitalsHistoryProjection:
    """
    patient_id → list of optional vitals events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        try:
            if event["type"] != "OptionalVitalsRecorded":
                return

            payload = event.get("payload", {})
            pid = payload.get("patient_id")
            if not pid:
                return

            self.state[pid].append(payload)

        except Exception as e:
            print(f"[OPTIONAL VITALS HISTORY ERROR] {e}")


# ---------------------------------------------------------------------------
# Registration with the world
# ---------------------------------------------------------------------------

def register(world):
    """
    Called automatically by world.load_modules().
    """

    try:
        world.add_schema("OptionalVitalsRecorded", OPTIONAL_VITALS_SCHEMA)
    except Exception as e:
        print(f"[OPTIONAL VITALS SCHEMA ERROR] {e}")

    try:
        world.add_projection("latest_optional_vitals", LatestOptionalVitalsProjection())
        world.add_projection("optional_vitals_history", OptionalVitalsHistoryProjection())
    except Exception as e:
        print(f"[OPTIONAL VITALS PROJECTION REGISTER ERROR] {e}")

    try:
        world.route_event_type("OptionalVitalsRecorded")
    except Exception as e:
        print(f"[OPTIONAL VITALS EVENT TYPE ERROR] {e}")


# ---------------------------------------------------------------------------
# Interactive form (safe)
# ---------------------------------------------------------------------------

def run_optional_vitals_form(world):
    """
    Crash‑proof optional vitals entry form.
    """

    print("\n--- Optional Vitals Form ---")

    try:
        pid = input("Patient ID: ").strip()
        timestamp = input("Timestamp (YYYY-MM-DD HH:MM): ").strip()
        performed_by = input("Performed by: ").strip()

        height_cm = input("Height (cm): ").strip()
        height_in = input("Height (in): ").strip()
        weight_kg = input("Weight (kg): ").strip()
        weight_lb = input("Weight (lb): ").strip()
        bmi = input("BMI: ").strip()
        waist_cm = input("Waist circumference (cm): ").strip()
        waist_in = input("Waist circumference (in): ").strip()
        head_cm = input("Head circumference (cm): ").strip()
        head_in = input("Head circumference (in): ").strip()
        notes = input("Notes: ").strip()

        event = {
            "type": "OptionalVitalsRecorded",
            "patient_id": pid,
            "timestamp": timestamp,
            "performed_by": performed_by,
            "consent_given": True,
        }

        # Safe numeric conversions
        if safe_float(height_cm) is not None:
            event["height_cm"] = safe_float(height_cm)

        if safe_float(height_in) is not None:
            event["height_in"] = safe_float(height_in)

        if safe_float(weight_kg) is not None:
            event["weight_kg"] = safe_float(weight_kg)

        if safe_float(weight_lb) is not None:
            event["weight_lb"] = safe_float(weight_lb)

        if safe_float(bmi) is not None:
            event["bmi"] = safe_float(bmi)

        if safe_float(waist_cm) is not None:
            event["waist_circumference_cm"] = safe_float(waist_cm)

        if safe_float(waist_in) is not None:
            event["waist_circumference_in"] = safe_float(waist_in)

        if safe_float(head_cm) is not None:
            event["head_circumference_cm"] = safe_float(head_cm)

        if safe_float(head_in) is not None:
            event["head_circumference_in"] = safe_float(head_in)

        if notes:
            event["notes"] = notes

        print("\nGenerated event:")
        import json
        print(json.dumps(event, indent=2))

        confirm = input("Append to event log? (y/n): ").strip().lower()
        if confirm == "y":
            try:
                world.append(event)
                print("Event appended.\n")
            except Exception as e:
                print(f"[OPTIONAL VITALS APPEND ERROR] {e}")
        else:
            print("Cancelled.\n")

    except Exception as e:
        print(f"[OPTIONAL VITALS FORM ERROR] {e}")


# ---------------------------------------------------------------------------
# Command registration
# ---------------------------------------------------------------------------

def register_commands(registry):
    try:
        registry.register(
            name="optional-vitals",
            handler=run_optional_vitals_form,
            help_text="Enter optional vitals",
            category="clinical",
        )
    except Exception as e:
        print(f"[OPTIONAL VITALS COMMAND ERROR] {e}")
