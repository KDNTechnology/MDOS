# surgical_history.py
# MDOS Surgical History Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

SURGICAL_HISTORY_SCHEMAS = {
    "SurgeryRecorded": {
        "required": [
            "patient_id",
            "timestamp",
            "recorded_by",
            "procedure_name",
        ],
        "optional": ["date_of_surgery", "surgeon", "facility", "notes"],
    },

    "SurgeryRemoved": {
        "required": [
            "patient_id",
            "timestamp",
            "removed_by",
            "procedure_name",
        ],
        "optional": ["reason"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class SurgicalHistoryProjection:
    """
    patient_id → list of surgical history entries
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        et = event["type"]
        pid = event["patient_id"]

        if et == "SurgeryRecorded":
            self.state[pid].append({
                "procedure_name": event["procedure_name"],
                "date_of_surgery": event.get("date_of_surgery"),
                "surgeon": event.get("surgeon"),
                "facility": event.get("facility"),
                "timestamp": event["timestamp"],
                "recorded_by": event["recorded_by"],
                "notes": event.get("notes"),
            })

        elif et == "SurgeryRemoved":
            self.state[pid] = [
                entry for entry in self.state[pid]
                if entry["procedure_name"] != event["procedure_name"]
            ]
