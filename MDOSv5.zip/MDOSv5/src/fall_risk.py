# fall_risk.py
# MDOS Fall Risk Assessment Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

FALL_RISK_SCHEMAS = {
    "FallRiskAssessed": {
        "required": [
            "patient_id",
            "timestamp",
            "assessed_by",
            "risk_level",
        ],
        "optional": [
            "history_of_falls",
            "gait_instability",
            "assistive_device",
            "medications_contributing",
            "cognitive_impairment",
            "environmental_factors",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestFallRiskProjection:
    """
    patient_id → latest fall risk assessment
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "FallRiskAssessed":
            return

        pid = event["patient_id"]

        snapshot = {
            "risk_level": event["risk_level"],
            "timestamp": event["timestamp"],
            "assessed_by": event["assessed_by"],
        }

        for key in [
            "history_of_falls",
            "gait_instability",
            "assistive_device",
            "medications_contributing",
            "cognitive_impairment",
            "environmental_factors",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class FallRiskHistoryProjection:
    """
    patient_id → list of fall risk assessments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "FallRiskAssessed":
            pid = event["patient_id"]
            self.state[pid].append(event)
