# src/scheduler.py

import time

class Scheduler:
    """
    Minimal cron-like scheduler organ.
    Allows registering periodic tasks that run every N seconds.
    """

    def __init__(self):
        self._scheduled_tasks = []

    def schedule(self, interval_seconds, func, name=None):
        self._scheduled_tasks.append({
            "interval": interval_seconds,
            "func": func,
            "name": name or func.__name__,
            "last_run": 0
        })

    def run_scheduler(self):
        print("Scheduler running (Ctrl+C to stop)...")
        try:
            while True:
                now = time.time()
                for task in self._scheduled_tasks:
                    if now - task["last_run"] >= task["interval"]:
                        print(f"Running scheduled task: {task['name']}")
                        task["func"]()
                        task["last_run"] = now
                time.sleep(0.25)
        except KeyboardInterrupt:
            print("Scheduler stopped.")
