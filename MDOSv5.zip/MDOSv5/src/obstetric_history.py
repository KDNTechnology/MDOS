# obstetric_history.py
# MDOS Obstetric History Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

OBSTETRIC_HISTORY_SCHEMAS = {
    "PregnancyRecorded": {
        "required": [
            "patient_id",
            "timestamp",
            "recorded_by",
            "pregnancy_id",
        ],
        "optional": [
            "gravida",
            "para",
            "estimated_due_date",
            "last_menstrual_period",
            "pregnancy_complications",
            "notes",
        ],
    },

    "DeliveryRecorded": {
        "required": [
            "patient_id",
            "timestamp",
            "recorded_by",
            "pregnancy_id",
            "delivery_date",
            "delivery_type",     # vaginal, c-section, assisted
        ],
        "optional": [
            "gestational_age_weeks",
            "infant_weight_grams",
            "apgar_scores",
            "maternal_complications",
            "notes",
        ],
    },

    "PregnancyOutcomeUpdated": {
        "required": [
            "patient_id",
            "timestamp",
            "updated_by",
            "pregnancy_id",
            "outcome",           # ongoing, live birth, miscarriage, stillbirth, termination
        ],
        "optional": ["notes"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class ObstetricHistoryProjection:
    """
    patient_id → structured obstetric history
    """

    def __init__(self):
        self.state = defaultdict(lambda: {
            "pregnancies": {},
            "deliveries": [],
            "outcomes": [],
        })

    def apply(self, event: Dict[str, Any]):
        pid = event["patient_id"]
        et = event["type"]

        if et == "PregnancyRecorded":
            preg_id = event["pregnancy_id"]
            self.state[pid]["pregnancies"][preg_id] = {
                "gravida": event.get("gravida"),
                "para": event.get("para"),
                "estimated_due_date": event.get("estimated_due_date"),
                "last_menstrual_period": event.get("last_menstrual_period"),
                "pregnancy_complications": event.get("pregnancy_complications"),
                "timestamp": event["timestamp"],
                "recorded_by": event["recorded_by"],
                "notes": event.get("notes"),
            }

        elif et == "DeliveryRecorded":
            self.state[pid]["deliveries"].append({
                "pregnancy_id": event["pregnancy_id"],
                "delivery_date": event["delivery_date"],
                "delivery_type": event["delivery_type"],
                "gestational_age_weeks": event.get("gestational_age_weeks"),
                "infant_weight_grams": event.get("infant_weight_grams"),
                "apgar_scores": event.get("apgar_scores"),
                "maternal_complications": event.get("maternal_complications"),
                "timestamp": event["timestamp"],
                "recorded_by": event["recorded_by"],
                "notes": event.get("notes"),
            })

        elif et == "PregnancyOutcomeUpdated":
            self.state[pid]["outcomes"].append({
                "pregnancy_id": event["pregnancy_id"],
                "outcome": event["outcome"],
                "timestamp": event["timestamp"],
                "updated_by": event["updated_by"],
                "notes": event.get("notes"),
            })
