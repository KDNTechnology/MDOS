# src/authorization_guard.py

class AuthorizationError(Exception):
    """Raised when a user attempts an unauthorized action."""
    pass


class AuthorizationGuard:
    """
    Minimal role-based authorization layer.
    Enforces:
      - which commands a role may invoke
      - which event types a role may emit
    """

    def __init__(self):
        # ─────────────────────────────────────────────
        # Role → allowed commands
        # ─────────────────────────────────────────────
        self.allowed_commands = {
            "owner": {
                "cash in", "cash out",
                "invoice issue", "invoice pay",
                "bill receive", "bill pay",
                "show cash", "show accrual", "show inventory",
                "show ar aging", "show ap aging",
                "show pnl", "show bs", "show cf",
                "log", "help",
"show fund", "show budget", "show grant", "show project",
"mi list", "mi approve", "mi reject", "mi apply",
"fund create", "fund transfer in", "fund transfer out",
"budget appropriate", "budget amend",
"encumbrance create", "encumbrance release",
"grant award", "grant receive", "grant restrict", "grant expend",
"project milestone", "project cost", "project revenue",



            },

            "clerk": {
                "cash in", "cash out",
                "invoice issue", "invoice pay",
                "bill receive", "bill pay",
                "show cash", "show accrual",
                "show ar aging", "show ap aging",
                "help",
# Clerks can view fund and project, but not budget/grant by default
"show fund", "show project",
"show events",
"show machine events",
"show business events",
"show gov events",


            },

            "auditor": {
                "show cash", "show accrual", "show inventory",
                "show ar aging", "show ap aging",
                "show pnl", "show bs", "show cf",
"show fund", "show budget", "show grant", "show project",
"mi list",
"show events",
"show machine events",
"show business events",
"show gov events",



                "log", "help",
            },

            "official": {
                # Governmental operations
                "show cash", "show accrual", "show inventory",
                "show ar aging", "show ap aging",
                "show pnl", "show bs", "show cf",
"show fund", "show budget", "show grant", "show project",
"mi list", "mi approve",
"show events",
"show machine events",
"show business events",
"show gov events",
"fund create", "fund transfer in", "fund transfer out",
"budget appropriate", "budget amend",
"encumbrance create", "encumbrance release",
"grant award", "grant receive", "grant restrict", "grant expend",
"project milestone", "project cost", "project revenue",




                "log", "help",
            },
        }

        # ─────────────────────────────────────────────
        # Role → allowed event types
        # ─────────────────────────────────────────────
        self.allowed_event_types = {
            "owner": "ALL",  # full control

            "clerk": {
                "cash_in", "cash_out",
                "invoice_issued", "invoice_paid",
                "bill_received", "bill_paid",

            },

            "auditor": set(),  # auditors cannot emit events

            "official": {
                # Governmental events only
                "budget_appropriated",
                "budget_amended",
                "encumbrance_created",
                "encumbrance_released",
                "tax_assessed",
                "tax_collected",
                "grant_received",
                "expenditure_authorized",
                "expenditure_incurred",
                "bond_issued",
                "bond_principal_paid",
                "bond_interest_paid",
                "fund_created",
                "fund_closed",
            },
        }

    # ─────────────────────────────────────────────
    # Command check
    # ─────────────────────────────────────────────

    def check_command(self, role: str, command: str):
        allowed = self.allowed_commands.get(role, set())
        if allowed == "ALL":
            return
        if command not in allowed:
            raise AuthorizationError(f"Role '{role}' is not allowed to run command '{command}'.")

    # ─────────────────────────────────────────────
    # Event type check
    # ─────────────────────────────────────────────

    def check_event(self, role: str, event_type: str):
        allowed = self.allowed_event_types.get(role, set())
        if allowed == "ALL":
            return
        if event_type not in allowed:
            raise AuthorizationError(f"Role '{role}' cannot emit event type '{event_type}'.")
