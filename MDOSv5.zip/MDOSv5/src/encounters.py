# encounters.py
# MDOS Encounter Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

ENCOUNTER_SCHEMAS = {
    "EncounterOpened": {
        "required": ["encounter_id", "patient_id", "timestamp", "opened_by"],
        "optional": ["location", "reason"],
    },
    "EncounterClosed": {
        "required": ["encounter_id", "patient_id", "timestamp", "closed_by"],
        "optional": ["summary"],
    },
    "ClinicalNoteAdded": {
        "required": ["encounter_id", "patient_id", "timestamp", "author"],
        "optional": ["note_type", "content"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class EncounterStateProjection:
    """
    encounter_id → { patient_id, opened_by, closed_by, notes, timestamps }
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        et = event["type"]
        enc = event.get("encounter_id")

        if not enc:
            return

        if et == "EncounterOpened":
            self.state[enc] = {
                "patient_id": event["patient_id"],
                "opened_by": event["opened_by"],
                "timestamp_opened": event["timestamp"],
                "timestamp_closed": None,
                "closed_by": None,
                "notes": [],
            }

        elif et == "EncounterClosed":
            if enc in self.state:
                self.state[enc]["timestamp_closed"] = event["timestamp"]
                self.state[enc]["closed_by"] = event["closed_by"]

        elif et == "ClinicalNoteAdded":
            if enc in self.state:
                self.state[enc]["notes"].append({
                    "timestamp": event["timestamp"],
                    "author": event["author"],
                    "note_type": event.get("note_type"),
                    "content": event.get("content"),
                })


class EncounterTimelineProjection:
    """
    patient_id → list of encounter events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        pid = event.get("patient_id")
        if pid:
            self.state[pid].append(event)
