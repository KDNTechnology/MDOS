# patient_identity.py
# MDOS Patient Identity Module
# Pure event schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

PATIENT_IDENTITY_SCHEMAS = {
    "PatientRegistered": {
        "required": ["patient_id", "timestamp", "registered_by"],
        "optional": ["demographics", "contact_info", "notes"],
    },
    "PatientUpdated": {
        "required": ["patient_id", "timestamp", "updated_by"],
        "optional": ["demographics", "contact_info", "notes"],
    },
    "PatientArchived": {
        "required": ["patient_id", "timestamp", "archived_by"],
        "optional": ["reason"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class PatientDirectoryProjection:
    """
    patient_id → { demographics, contact_info, status }
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        et = event["type"]
        pid = event.get("patient_id")

        if not pid:
            return

        if et == "PatientRegistered":
            self.state[pid] = {
                "demographics": event.get("demographics"),
                "contact_info": event.get("contact_info"),
                "status": "active",
                "last_updated": event["timestamp"],
            }

        elif et == "PatientUpdated":
            if pid not in self.state:
                return
            if "demographics" in event:
                self.state[pid]["demographics"] = event["demographics"]
            if "contact_info" in event:
                self.state[pid]["contact_info"] = event["contact_info"]
            self.state[pid]["last_updated"] = event["timestamp"]

        elif et == "PatientArchived":
            if pid in self.state:
                self.state[pid]["status"] = "archived"
                self.state[pid]["last_updated"] = event["timestamp"]


class PatientHistoryProjection:
    """
    patient_id → chronological list of identity events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        pid = event.get("patient_id")
        if pid:
            self.state[pid].append(event)
