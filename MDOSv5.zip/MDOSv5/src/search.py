# src/search.py

class Search:
    """
    Full-text and field-based search organ.
    Supports searching across:
      - business events
      - governmental events
      - machine events
      - MI proposals
    """

    def search(self, query):
        query = query.lower().strip()
        print(f"\n=== SEARCH: '{query}' ===")

        # Business events
        print("\n--- Business Events ---")
        for ev in self.log.events:
            if query in str(ev.__dict__).lower():
                print(ev)

        # Governmental events
        print("\n--- Governmental Events ---")
        for ev in self.gov_events:
            if query in str(ev.__dict__).lower():
                print(ev)

        # Machine events
        print("\n--- Machine Events ---")
        for ev in self.machine_store.load_all():
            if query in str(ev.__dict__).lower():
                print(ev)

        # MI proposals
        print("\n--- MI Proposals ---")
        for pid, proposal in self.mi_substrate.proposals.items():
            if query in str(proposal).lower():
                print(f"{pid}: {proposal}")

        print("\nSearch complete.\n")
