# src/orderly/modules/vitals.py
# MDOS Vitals Module — crash‑proof, payload‑aware

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Safe helpers
# ---------------------------------------------------------------------------

def safe_float(val):
    try:
        return float(val)
    except:
        return None


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

VITALS_SCHEMA = {
    "required": [
        "patient_id",
        "timestamp",
        "performed_by",
    ],
    "optional": [
        "heart_rate_bpm",
        "respiratory_rate_bpm",
        "blood_pressure_systolic",
        "blood_pressure_diastolic",
        "temperature_c",
        "temperature_f",
        "oxygen_saturation_pct",
        "pain_score",
        "notes",
    ],
}


# ---------------------------------------------------------------------------
# Projections (payload‑aware)
# ---------------------------------------------------------------------------

class LatestVitalsProjection:
    """
    patient_id → latest vitals snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        try:
            if event["type"] != "VitalsRecorded":
                return

            payload = event.get("payload", {})
            pid = payload.get("patient_id")
            if not pid:
                return

            snapshot = {
                "timestamp": payload.get("timestamp"),
                "performed_by": payload.get("performed_by"),
            }

            for key in VITALS_SCHEMA["optional"]:
                if key in payload:
                    snapshot[key] = payload[key]

            self.state[pid] = snapshot

        except Exception as e:
            print(f"[VITALS PROJECTION ERROR] {e}")


class VitalsHistoryProjection:
    """
    patient_id → list of vitals events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        try:
            if event["type"] != "VitalsRecorded":
                return

            payload = event.get("payload", {})
            pid = payload.get("patient_id")
            if not pid:
                return

            self.state[pid].append(payload)

        except Exception as e:
            print(f"[VITALS HISTORY ERROR] {e}")


# ---------------------------------------------------------------------------
# Registration with the world
# ---------------------------------------------------------------------------

def register(world):
    """
    Called automatically by world.load_modules().
    """

    try:
        world.add_schema("VitalsRecorded", VITALS_SCHEMA)
    except Exception as e:
        print(f"[VITALS SCHEMA ERROR] {e}")

    try:
        world.add_projection("latest_vitals", LatestVitalsProjection())
        world.add_projection("vitals_history", VitalsHistoryProjection())
    except Exception as e:
        print(f"[VITALS PROJECTION REGISTER ERROR] {e}")

    try:
        world.route_event_type("VitalsRecorded")
    except Exception as e:
        print(f"[VITALS EVENT TYPE ERROR] {e}")


# ---------------------------------------------------------------------------
# Interactive form (safe)
# ---------------------------------------------------------------------------

def run_vitals_form(world):
    """
    Crash‑proof vitals entry form.
    """

    print("\n--- Vitals Form ---")

    try:
        pid = input("Patient ID: ").strip()
        timestamp = input("Timestamp (YYYY-MM-DD HH:MM): ").strip()
        performed_by = input("Performed by: ").strip()

        hr = input("Heart rate (bpm): ").strip()
        rr = input("Respiratory rate (bpm): ").strip()
        sys = input("Blood pressure systolic: ").strip()
        dia = input("Blood pressure diastolic: ").strip()
        temp_c = input("Temperature (°C): ").strip()
        temp_f = input("Temperature (°F): ").strip()
        spo2 = input("Oxygen saturation (%): ").strip()
        pain = input("Pain score (0–10): ").strip()
        notes = input("Notes: ").strip()

        event = {
            "type": "VitalsRecorded",
            "patient_id": pid,
            "timestamp": timestamp,
            "performed_by": performed_by,
            "consent_given": True,
        }

        # Safe numeric conversions
        if safe_float(hr) is not None:
            event["heart_rate_bpm"] = safe_float(hr)

        if safe_float(rr) is not None:
            event["respiratory_rate_bpm"] = safe_float(rr)

        if safe_float(sys) is not None:
            event["blood_pressure_systolic"] = safe_float(sys)

        if safe_float(dia) is not None:
            event["blood_pressure_diastolic"] = safe_float(dia)

        if safe_float(temp_c) is not None:
            event["temperature_c"] = safe_float(temp_c)

        if safe_float(temp_f) is not None:
            event["temperature_f"] = safe_float(temp_f)

        if safe_float(spo2) is not None:
            event["oxygen_saturation_pct"] = safe_float(spo2)

        if safe_float(pain) is not None:
            event["pain_score"] = safe_float(pain)

        if notes:
            event["notes"] = notes

        print("\nGenerated event:")
        import json
        print(json.dumps(event, indent=2))

        confirm = input("Append to event log? (y/n): ").strip().lower()
        if confirm == "y":
            try:
                world.append(event)
                print("Event appended.\n")
            except Exception as e:
                print(f"[VITALS APPEND ERROR] {e}")
        else:
            print("Cancelled.\n")

    except Exception as e:
        print(f"[VITALS FORM ERROR] {e}")


# ---------------------------------------------------------------------------
# Command registration
# ---------------------------------------------------------------------------

def register_commands(registry):
    try:
        registry.register(
            name="vitals",
            handler=run_vitals_form,
            help_text="Enter a vitals assessment",
            category="clinical",
        )
    except Exception as e:
        print(f"[VITALS COMMAND ERROR] {e}")
