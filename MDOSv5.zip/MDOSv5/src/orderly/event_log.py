# src/orderly/event_log.py
# Cryptographic event stream for Omega / MDOS

import json
import hashlib
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, Iterable, List

PROJECT_ROOT = Path(__file__).resolve().parents[2]
LOGS_DIR = PROJECT_ROOT / "src" / "logs"
EVENT_LOG_PATH = LOGS_DIR / "events.log"


def _ensure_dirs():
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    EVENT_LOG_PATH.touch(exist_ok=True)


def _hash_event(event: Dict[str, Any]) -> str:
    # Stable hash over selected fields
    payload = json.dumps(
        {
            "id": event["id"],
            "timestamp": event["timestamp"],
            "type": event["type"],
            "payload": event.get("payload", {}),
            "prev_hash": event.get("prev_hash", ""),
        },
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def append_event(event: Dict[str, Any]) -> Dict[str, Any]:
    """
    Append a single event to the cryptographic log.
    Fills id, timestamp, prev_hash, hash.
    """
    _ensure_dirs()

    # Load last hash (if any)
    last_hash = ""
    with EVENT_LOG_PATH.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                e = json.loads(line)
                last_hash = e.get("hash", "")
            except json.JSONDecodeError:
                continue

    # Normalize event
    if "id" not in event:
        event["id"] = str(uuid.uuid4())

    if "timestamp" not in event:
        event["timestamp"] = datetime.now(timezone.utc).isoformat()

    if "type" not in event:
        raise ValueError("Event must include 'type'")

    # Wrap payload (keep top-level clean)
    if "payload" not in event:
        # move non-core keys into payload
        payload = {
            k: v
            for k, v in event.items()
            if k not in ("id", "timestamp", "type", "prev_hash", "hash")
        }
        event = {
            "id": event["id"],
            "timestamp": event["timestamp"],
            "type": event["type"],
            "payload": payload,
        }

    event["prev_hash"] = last_hash
    event["hash"] = _hash_event(event)

    # Append
    with EVENT_LOG_PATH.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, separators=(",", ":"), sort_keys=True) + "\n")

    return event


def read_events() -> Iterable[Dict[str, Any]]:
    """
    Stream events from the log, verifying the hash chain.
    Raises ValueError on integrity failure.
    """
    _ensure_dirs()
    prev_hash = ""
    with EVENT_LOG_PATH.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            e = json.loads(line)
            # verify chain
            if e.get("prev_hash", "") != prev_hash:
                raise ValueError("Event log hash chain broken")
            expected = _hash_event(e)
            if e.get("hash") != expected:
                raise ValueError("Event hash mismatch")
            prev_hash = e["hash"]
            yield e


def bootstrap() -> None:
    """
    Idempotent: just ensures the log exists.
    """
    _ensure_dirs()


def rebuild_events() -> List[Dict[str, Any]]:
    """
    Convenience: load all events into memory (for world replay).
    """
    return list(read_events())
