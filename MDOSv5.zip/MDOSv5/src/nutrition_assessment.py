# nutrition_assessment.py
# MDOS Nutrition Assessment Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

NUTRITION_ASSESSMENT_SCHEMAS = {
    "NutritionAssessmentRecorded": {
        "required": [
            "patient_id",
            "timestamp",
            "recorded_by",
        ],
        "optional": [
            "bmi",
            "weight_kg",
            "height_cm",
            "dietary_intake",
            "malnutrition_risk",
            "swallowing_issues",
            "appetite_level",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestNutritionAssessmentProjection:
    """
    patient_id → latest nutrition assessment snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "NutritionAssessmentRecorded":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "recorded_by": event["recorded_by"],
        }

        for key in [
            "bmi",
            "weight_kg",
            "height_cm",
            "dietary_intake",
            "malnutrition_risk",
            "swallowing_issues",
            "appetite_level",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class NutritionAssessmentHistoryProjection:
    """
    patient_id → list of nutrition assessments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "NutritionAssessmentRecorded":
            pid = event["patient_id"]
            self.state[pid].append(event)
