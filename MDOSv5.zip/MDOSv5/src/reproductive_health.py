# reproductive_health.py
# MDOS Reproductive Health Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

REPRODUCTIVE_HEALTH_SCHEMAS = {
    "MenstrualHistoryUpdated": {
        "required": [
            "patient_id",
            "timestamp",
            "updated_by",
        ],
        "optional": [
            "cycle_length_days",
            "period_duration_days",
            "flow_intensity",
            "dysmenorrhea",
            "last_menstrual_period",
            "irregular_cycles",
            "notes",
        ],
    },

    "FertilityAssessmentRecorded": {
        "required": [
            "patient_id",
            "timestamp",
            "recorded_by",
        ],
        "optional": [
            "trying_to_conceive",
            "infertility_duration_months",
            "ovulation_tracking",
            "partner_factors",
            "prior_fertility_treatments",
            "notes",
        ],
    },

    "ContraceptionUpdated": {
        "required": [
            "patient_id",
            "timestamp",
            "updated_by",
            "method",              # IUD, pill, implant, condoms, none
        ],
        "optional": [
            "start_date",
            "end_date",
            "side_effects",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class ReproductiveHealthProjection:
    """
    patient_id → structured reproductive health history
    """

    def __init__(self):
        self.state = defaultdict(lambda: {
            "menstrual_history": [],
            "fertility_assessments": [],
            "contraception_history": [],
        })

    def apply(self, event: Dict[str, Any]):
        pid = event["patient_id"]
        et = event["type"]

        if et == "MenstrualHistoryUpdated":
            self.state[pid]["menstrual_history"].append({
                "cycle_length_days": event.get("cycle_length_days"),
                "period_duration_days": event.get("period_duration_days"),
                "flow_intensity": event.get("flow_intensity"),
                "dysmenorrhea": event.get("dysmenorrhea"),
                "last_menstrual_period": event.get("last_menstrual_period"),
                "irregular_cycles": event.get("irregular_cycles"),
                "timestamp": event["timestamp"],
                "updated_by": event["updated_by"],
                "notes": event.get("notes"),
            })

        elif et == "FertilityAssessmentRecorded":
            self.state[pid]["fertility_assessments"].append({
                "trying_to_conceive": event.get("trying_to_conceive"),
                "infertility_duration_months": event.get("infertility_duration_months"),
                "ovulation_tracking": event.get("ovulation_tracking"),
                "partner_factors": event.get("partner_factors"),
                "prior_fertility_treatments": event.get("prior_fertility_treatments"),
                "timestamp": event["timestamp"],
                "recorded_by": event["recorded_by"],
                "notes": event.get("notes"),
            })

        elif et == "ContraceptionUpdated":
            self.state[pid]["contraception_history"].append({
                "method": event["method"],
                "start_date": event.get("start_date"),
                "end_date": event.get("end_date"),
                "side_effects": event.get("side_effects"),
                "timestamp": event["timestamp"],
                "updated_by": event["updated_by"],
                "notes": event.get("notes"),
            })
