# src/orderly/patient_snapshot.py
# Build a unified patient snapshot from all projections

def build_patient_snapshot(world, patient_id):
    state = world.projections.get_state()

    return {
        "genesis": state.get("patient_directory", {}).get(patient_id),
        "latest_vitals": state.get("latest_vitals", {}).get(patient_id),
        "vitals_history": state.get("vitals_history", {}).get(patient_id, []),
        "latest_gait": state.get("latest_gait_assessment", {}).get(patient_id),
        "gait_history": state.get("gait_assessment_history", {}).get(patient_id, []),
        "latest_optional_vitals": state.get("latest_optional_vitals", {}).get(patient_id),
        "optional_vitals_history": state.get("optional_vitals_history", {}).get(patient_id, []),
    }
