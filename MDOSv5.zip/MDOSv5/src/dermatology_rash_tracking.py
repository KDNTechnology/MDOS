# dermatology_rash_tracking.py
# MDOS Dermatology Rash Tracking Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

DERM_RASH_SCHEMAS = {
    "RashDocumented": {
        "required": [
            "patient_id",
            "timestamp",
            "documented_by",
            "rash_id",
        ],
        "optional": [
            "morphology",          # macule, papule, vesicle, plaque, etc.
            "distribution",        # localized, dermatomal, generalized
            "color",
            "size_mm",
            "border",
            "scaling",
            "pruritus",
            "onset_date",
            "notes",
        ],
    },

    "RashUpdated": {
        "required": [
            "patient_id",
            "timestamp",
            "updated_by",
            "rash_id",
        ],
        "optional": [
            "morphology",
            "distribution",
            "color",
            "size_mm",
            "border",
            "scaling",
            "pruritus",
            "notes",
        ],
    },

    "RashResolved": {
        "required": [
            "patient_id",
            "timestamp",
            "resolved_by",
            "rash_id",
        ],
        "optional": ["resolution_notes"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class ActiveRashesProjection:
    """
    patient_id → { rash_id → latest rash snapshot }
    """

    def __init__(self):
        self.state = defaultdict(dict)

    def apply(self, event: Dict[str, Any]):
        et = event["type"]
        pid = event["patient_id"]
        rid = event["rash_id"]

        if et in ("RashDocumented", "RashUpdated"):
            snapshot = {
                "timestamp": event["timestamp"],
                "by": event.get("documented_by") or event.get("updated_by"),
            }

            for key in [
                "morphology",
                "distribution",
                "color",
                "size_mm",
                "border",
                "scaling",
                "pruritus",
                "onset_date",
                "notes",
            ]:
                if key in event:
                    snapshot[key] = event[key]

            self.state[pid][rid] = snapshot

        elif et == "RashResolved":
            if rid in self.state[pid]:
                del self.state[pid][rid]


class RashHistoryProjection:
    """
    patient_id → list of rash events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] in ("RashDocumented", "RashUpdated", "RashResolved"):
            pid = event["patient_id"]
            self.state[pid].append(event)
