# problems_list.py
# MDOS Problem List Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

PROBLEM_LIST_SCHEMAS = {
    "ProblemAdded": {
        "required": [
            "patient_id",
            "timestamp",
            "added_by",
            "problem_code",
        ],
        "optional": ["notes"],
    },

    "ProblemResolved": {
        "required": [
            "patient_id",
            "timestamp",
            "resolved_by",
            "problem_code",
        ],
        "optional": ["resolution_notes"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class ActiveProblemListProjection:
    """
    patient_id → set of active problem codes
    """

    def __init__(self):
        self.state = defaultdict(set)

    def apply(self, event: Dict[str, Any]):
        et = event["type"]
        pid = event["patient_id"]

        if et == "ProblemAdded":
            self.state[pid].add(event["problem_code"])

        elif et == "ProblemResolved":
            code = event["problem_code"]
            if code in self.state[pid]:
                self.state[pid].remove(code)


class ProblemHistoryProjection:
    """
    patient_id → list of all problem list events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] in ("ProblemAdded", "ProblemResolved"):
            pid = event["patient_id"]
            self.state[pid].append(event)
