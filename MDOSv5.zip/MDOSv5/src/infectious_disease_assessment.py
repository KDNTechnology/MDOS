# infectious_disease_assessment.py
# MDOS Infectious Disease Assessment Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

INFECTIOUS_DISEASE_ASSESSMENT_SCHEMAS = {
    "InfectiousDiseaseAssessmentPerformed": {
        "required": [
            "patient_id",
            "timestamp",
            "performed_by",
        ],
        "optional": [
            "fever",
            "chills",
            "sweats",
            "cough",
            "sore_throat",
            "shortness_of_breath",
            "rash",
            "diarrhea",
            "recent_travel",
            "exposure_history",
            "immunocompromised_status",
            "suspected_source",
            "notes",
        ],
    },
}
    

# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestInfectiousDiseaseAssessmentProjection:
    """
    patient_id → latest infectious disease assessment snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "InfectiousDiseaseAssessmentPerformed":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "performed_by": event["performed_by"],
        }

        for key in [
            "fever",
            "chills",
            "sweats",
            "cough",
            "sore_throat",
            "shortness_of_breath",
            "rash",
            "diarrhea",
            "recent_travel",
            "exposure_history",
            "immunocompromised_status",
            "suspected_source",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class InfectiousDiseaseAssessmentHistoryProjection:
    """
    patient_id → list of infectious disease assessments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "InfectiousDiseaseAssessmentPerformed":
            pid = event["patient_id"]
            self.state[pid].append(event)
