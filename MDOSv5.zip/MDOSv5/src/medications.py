# medications.py
# MDOS Medication Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

MEDICATION_SCHEMAS = {
    "MedicationPrescribed": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "prescribed_by",
            "medication_name",
        ],
        "optional": ["dose", "route", "frequency", "duration", "notes"],
    },
    "MedicationAdministered": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "administered_by",
            "medication_name",
        ],
        "optional": ["dose", "route", "notes"],
    },
    "MedicationDiscontinued": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "discontinued_by",
            "medication_name",
        ],
        "optional": ["reason"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class ActiveMedicationsProjection:
    """
    patient_id → { medication_name → details }
    """

    def __init__(self):
        self.state = defaultdict(dict)

    def apply(self, event: Dict[str, Any]):
        et = event.get("type")
        pid = event.get("patient_id")
        if not pid:
            return

        if et == "MedicationPrescribed":
            name = event["medication_name"]
            self.state[pid][name] = {
                "dose": event.get("dose"),
                "route": event.get("route"),
                "frequency": event.get("frequency"),
                "duration": event.get("duration"),
                "timestamp": event["timestamp"],
                "prescribed_by": event["prescribed_by"],
            }

        elif et == "MedicationDiscontinued":
            name = event["medication_name"]
            if name in self.state[pid]:
                del self.state[pid][name]


class MedicationHistoryProjection:
    """
    patient_id → list of all medication-related events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        et = event.get("type")
        if et in (
            "MedicationPrescribed",
            "MedicationAdministered",
            "MedicationDiscontinued",
        ):
            pid = event["patient_id"]
            self.state[pid].append(event)
