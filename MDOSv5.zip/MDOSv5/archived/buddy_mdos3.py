# src/orderly/buddy_mdos.py
# MDOS Buddy — constitutional REPL for entering events

import json
from typing import Any, Dict

from .terminal_ui import render_terminal


def print_banner():
    print("\nMDOS — Constitutional Buddy")
    print("---------------------------")
    print("Commands:")
    print("  genesis                  → create a PatientGenesis event interactively")
    print("  patients                 → list all patients")
    print("  projection <patient_id>  → open HTML patient page")
    print("  state                    → show all projections")
    print("  reload                   → rebuild projections from event log")
    print("  commands                 → show all commands")
    print("  quit                     → exit\n")
    print("Enter raw JSON events or use commands.\n")


def interactive_genesis(world):
    """
    Walk the user through creating a PatientGenesis event.
    """
    print("\n--- Patient Genesis Form ---")
    pid = input("Patient ID: ").strip()
    name = input("Name: ").strip()
    dob = input("DOB (YYYY-MM-DD): ").strip()
    created_by = input("Created by: ").strip()

    # Optional fields
    extra = {}
    for field in [
        "sex",
        "gender_identity",
        "pronouns",
        "contact_phone",
        "contact_email",
        "address",
        "notes",
    ]:
        val = input(f"{field} (optional): ").strip()
        if val:
            extra[field] = val

    # Build event using the module's helper
    from .patient_genesis import build_patient_genesis_event
    event = build_patient_genesis_event(
        patient_id=pid,
        name=name,
        dob=dob,
        created_by=created_by,
        **extra,
    )

    print("\nGenerated event:")
    print(json.dumps(event, indent=2))

    confirm = input("Append to event log? (y/n): ").strip().lower()
    if confirm == "y":
        world.append(event)
        print("Event appended.\n")
    else:
        print("Cancelled.\n")


def run(world):
    """
    Main REPL loop.
    world must expose:
      - world.append(event)
      - world.rebuild()
      - world.projections.get_state()
    """
    print_banner()

    while True:
        # Draw the structured terminal UI
        render_terminal(world)

        raw = input("> ").strip()
        if not raw:
            continue

        cmd = raw.lower()

        # Quit
        if cmd in ("quit", "exit", "q"):
            print("Goodbye.")
            break

        # Show all projections
        if cmd == "state":
            state = world.projections.get_state()
            print(json.dumps(state, indent=2, default=str))
            input("Press Enter to continue...")
            continue

        # Rebuild projections
        if cmd == "reload":
            world.rebuild()
            print("Projections rebuilt.")
            input("Press Enter to continue...")
            continue

        # Patient genesis form
        if cmd == "genesis":
            interactive_genesis(world)
            input("Press Enter to continue...")
            continue

        # List all patients
        if cmd == "patients":
            directory = world.projections.get_state().get("patient_directory", {})
            if not directory:
                print("\nNo patients found.\n")
                input("Press Enter to continue...")
                continue

            print("\n--- Patient List ---")
            for pid, patient in directory.items():
                print(f" {pid}  →  {patient.get('name')}  (DOB: {patient.get('dob')})")
            print("")
            input("Press Enter to continue...")
            continue

        # Commands list
        if cmd == "commands":
            print("\n--- Available Commands ---")
            print("  genesis                  → create a new patient")
            print("  patients                 → list all patients")
            print("  projection <patient_id>  → open HTML patient page")
            print("  state                    → show all projections")
            print("  reload                   → rebuild projections from event log")
            print("  commands                 → show this list")
            print("  quit                     → exit")
            print("")
            input("Press Enter to continue...")
            continue

        # Magic word: projection <patient_id>
        if cmd.startswith("projection "):
            pid = cmd.split(" ", 1)[1].strip()
            directory = world.projections.get_state().get("patient_directory", {})
            patient = directory.get(pid)

            if not patient:
                print(f"No patient with ID {pid}")
                input("Press Enter to continue...")
                continue

            from .html_renderer import render_patient_page
            render_patient_page(patient)
            input("Press Enter to continue...")
            continue

        # Otherwise treat input as raw JSON event
        try:
            event = json.loads(raw)
        except json.JSONDecodeError as e:
            print(f"[!] Invalid JSON: {e}")
            input("Press Enter to continue...")
            continue

        # Constitutional consent gate
        etype = event.get("type", "")
        if not (etype.startswith(("Consent", "System")) or event.get("consent_given", False)):
            print('[!] Consent missing — add "consent_given": true')
            input("Press Enter to continue...")
            continue

        # Append event
        try:
            world.append(event)
            print("Event appended.")
        except Exception as e:
            print(f"[APPEND ERROR] {e}")

        input("Press Enter to continue...")
