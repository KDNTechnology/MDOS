# family_history.py
# MDOS Family History Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

FAMILY_HISTORY_SCHEMAS = {
    "FamilyHistoryAdded": {
        "required": [
            "patient_id",
            "timestamp",
            "added_by",
            "relative",
            "condition",
        ],
        "optional": ["age_of_onset", "notes"],
    },

    "FamilyHistoryRemoved": {
        "required": [
            "patient_id",
            "timestamp",
            "removed_by",
            "relative",
            "condition",
        ],
        "optional": ["reason"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class FamilyHistoryProjection:
    """
    patient_id → list of family history entries
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        et = event["type"]
        pid = event["patient_id"]

        if et == "FamilyHistoryAdded":
            self.state[pid].append({
                "relative": event["relative"],
                "condition": event["condition"],
                "age_of_onset": event.get("age_of_onset"),
                "timestamp": event["timestamp"],
                "added_by": event["added_by"],
                "notes": event.get("notes"),
            })

        elif et == "FamilyHistoryRemoved":
            # Remove matching entries
            self.state[pid] = [
                entry for entry in self.state[pid]
                if not (
                    entry["relative"] == event["relative"]
                    and entry["condition"] == event["condition"]
                )
            ]
