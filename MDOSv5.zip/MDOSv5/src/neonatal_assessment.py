# neonatal_assessment.py
# MDOS Neonatal Assessment Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

NEONATAL_ASSESSMENT_SCHEMAS = {
    "NeonatalAssessmentPerformed": {
        "required": [
            "patient_id",
            "timestamp",
            "performed_by",
        ],
        "optional": [
            "apgar_scores",              # {1_min: X, 5_min: Y, 10_min: Z}
            "birth_weight_grams",
            "gestational_age_weeks",
            "feeding_method",            # breast, formula, mixed
            "jaundice_level",
            "respiratory_status",
            "temperature_celsius",
            "reflexes",                  # rooting, sucking, moro, grasp
            "congenital_findings",
            "notes",
        ],
    },
}
    

# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestNeonatalAssessmentProjection:
    """
    patient_id → latest neonatal assessment snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "NeonatalAssessmentPerformed":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "performed_by": event["performed_by"],
        }

        for key in [
            "apgar_scores",
            "birth_weight_grams",
            "gestational_age_weeks",
            "feeding_method",
            "jaundice_level",
            "respiratory_status",
            "temperature_celsius",
            "reflexes",
            "congenital_findings",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class NeonatalAssessmentHistoryProjection:
    """
    patient_id → list of neonatal assessments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "NeonatalAssessmentPerformed":
            pid = event["patient_id"]
            self.state[pid].append(event)
