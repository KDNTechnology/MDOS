# immunization_history.py
# MDOS Immunization History Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

IMMUNIZATION_HISTORY_SCHEMAS = {
    "VaccineAdministered": {
        "required": [
            "patient_id",
            "timestamp",
            "administered_by",
            "vaccine_name",
        ],
        "optional": [
            "dose_number",
            "lot_number",
            "site",               # left arm, right thigh, etc.
            "route",              # IM, SC, oral
            "notes",
        ],
    },

    "VaccineReactionRecorded": {
        "required": [
            "patient_id",
            "timestamp",
            "recorded_by",
            "vaccine_name",
        ],
        "optional": [
            "reaction_description",
            "severity",
            "onset_time",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class ImmunizationHistoryProjection:
    """
    patient_id → structured immunization history
    """

    def __init__(self):
        self.state = defaultdict(lambda: {
            "vaccines": [],
            "reactions": [],
        })

    def apply(self, event: Dict[str, Any]):
        pid = event["patient_id"]
        et = event["type"]

        if et == "VaccineAdministered":
            self.state[pid]["vaccines"].append({
                "vaccine_name": event["vaccine_name"],
                "dose_number": event.get("dose_number"),
                "lot_number": event.get("lot_number"),
                "site": event.get("site"),
                "route": event.get("route"),
                "timestamp": event["timestamp"],
                "administered_by": event["administered_by"],
                "notes": event.get("notes"),
            })

        elif et == "VaccineReactionRecorded":
            self.state[pid]["reactions"].append({
                "vaccine_name": event["vaccine_name"],
                "reaction_description": event.get("reaction_description"),
                "severity": event.get("severity"),
                "onset_time": event.get("onset_time"),
                "timestamp": event["timestamp"],
                "recorded_by": event["recorded_by"],
                "notes": event.get("notes"),
            })
