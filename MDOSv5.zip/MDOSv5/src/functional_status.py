# functional_status.py
# MDOS Functional Status Module (ADLs / IADLs / Mobility)
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

FUNCTIONAL_STATUS_SCHEMAS = {
    "FunctionalStatusRecorded": {
        "required": [
            "patient_id",
            "timestamp",
            "recorded_by",
        ],
        "optional": [
            "adl_scores",          # bathing, dressing, toileting, feeding, transferring
            "iadl_scores",         # shopping, cooking, finances, meds, housekeeping
            "mobility_level",      # independent / walker / wheelchair / bedbound
            "assistive_devices",
            "fall_history",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestFunctionalStatusProjection:
    """
    patient_id → latest functional status snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "FunctionalStatusRecorded":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "recorded_by": event["recorded_by"],
        }

        for key in [
            "adl_scores",
            "iadl_scores",
            "mobility_level",
            "assistive_devices",
            "fall_history",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class FunctionalStatusHistoryProjection:
    """
    patient_id → list of functional status events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "FunctionalStatusRecorded":
            pid = event["patient_id"]
            self.state[pid].append(event)
