# dental_history.py
# MDOS Dental History Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

DENTAL_HISTORY_SCHEMAS = {
    "DentalProcedureRecorded": {
        "required": [
            "patient_id",
            "timestamp",
            "recorded_by",
            "procedure_name",
        ],
        "optional": ["tooth_number", "date", "provider", "notes"],
    },

    "DentalProcedureRemoved": {
        "required": [
            "patient_id",
            "timestamp",
            "removed_by",
            "procedure_name",
        ],
        "optional": ["reason"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class DentalHistoryProjection:
    """
    patient_id → list of dental procedures
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        et = event["type"]
        pid = event["patient_id"]

        if et == "DentalProcedureRecorded":
            self.state[pid].append({
                "procedure_name": event["procedure_name"],
                "tooth_number": event.get("tooth_number"),
                "date": event.get("date"),
                "provider": event.get("provider"),
                "timestamp": event["timestamp"],
                "recorded_by": event["recorded_by"],
                "notes": event.get("notes"),
            })

        elif et == "DentalProcedureRemoved":
            self.state[pid] = [
                entry for entry in self.state[pid]
                if entry["procedure_name"] != event["procedure_name"]
            ]
