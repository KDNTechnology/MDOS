# social_history.py
# MDOS Social History Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

SOCIAL_HISTORY_SCHEMAS = {
    "SocialHistoryUpdated": {
        "required": [
            "patient_id",
            "timestamp",
            "updated_by",
        ],
        "optional": [
            "tobacco_use",
            "alcohol_use",
            "drug_use",
            "occupation",
            "living_situation",
            "exercise_habits",
            "diet",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class SocialHistoryProjection:
    """
    patient_id → latest social history snapshot
    """

    def __init__(self):
        self.state = defaultdict(dict)

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "SocialHistoryUpdated":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "updated_by": event["updated_by"],
        }

        for key in [
            "tobacco_use",
            "alcohol_use",
            "drug_use",
            "occupation",
            "living_situation",
            "exercise_habits",
            "diet",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class SocialHistoryTimelineProjection:
    """
    patient_id → list of all social history updates
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "SocialHistoryUpdated":
            pid = event["patient_id"]
            self.state[pid].append(event)
