# endocrine_diabetes_monitoring.py
# MDOS Diabetes Monitoring Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

DIABETES_MONITORING_SCHEMAS = {
    "GlucoseReadingRecorded": {
        "required": [
            "patient_id",
            "timestamp",
            "recorded_by",
            "glucose_mg_dl",
        ],
        "optional": [
            "context",            # fasting, postprandial, random
            "symptoms",           # hypoglycemia symptoms, hyperglycemia symptoms
            "notes",
        ],
    },

    "HypoglycemiaEpisodeRecorded": {
        "required": [
            "patient_id",
            "timestamp",
            "recorded_by",
        ],
        "optional": [
            "glucose_mg_dl",
            "symptoms",
            "treatment_given",
            "notes",
        ],
    },

    "InsulinDoseChanged": {
        "required": [
            "patient_id",
            "timestamp",
            "changed_by",
            "insulin_type",
            "new_dose_units",
        ],
        "optional": ["reason", "notes"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class GlucoseHistoryProjection:
    """
    patient_id → list of glucose readings
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "GlucoseReadingRecorded":
            pid = event["patient_id"]
            self.state[pid].append(event)


class HypoglycemiaHistoryProjection:
    """
    patient_id → list of hypoglycemia episodes
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "HypoglycemiaEpisodeRecorded":
            pid = event["patient_id"]
            self.state[pid].append(event)


class InsulinDoseHistoryProjection:
    """
    patient_id → list of insulin dose changes
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "InsulinDoseChanged":
            pid = event["patient_id"]
            self.state[pid].append(event)
