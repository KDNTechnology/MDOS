# immunizations.py
# MDOS Immunization Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

IMMUNIZATION_SCHEMAS = {
    "ImmunizationAdministered": {
        "required": [
            "patient_id",
            "timestamp",
            "administered_by",
            "vaccine_name",
        ],
        "optional": ["lot_number", "expiration_date", "site", "notes"],
    },

    "ImmunizationRecordedExternally": {
        "required": [
            "patient_id",
            "timestamp",
            "recorded_by",
            "vaccine_name",
        ],
        "optional": ["source", "notes"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class ImmunizationHistoryProjection:
    """
    patient_id → list of all immunization events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] in (
            "ImmunizationAdministered",
            "ImmunizationRecordedExternally",
        ):
            pid = event["patient_id"]
            self.state[pid].append(event)


class ImmunizationStatusProjection:
    """
    patient_id → { vaccine_name → last administration }
    """

    def __init__(self):
        self.state = defaultdict(dict)

    def apply(self, event: Dict[str, Any]):
        et = event["type"]
        if et not in (
            "ImmunizationAdministered",
            "ImmunizationRecordedExternally",
        ):
            return

        pid = event["patient_id"]
        vaccine = event["vaccine_name"]

        self.state[pid][vaccine] = {
            "timestamp": event["timestamp"],
            "source": "external" if et == "ImmunizationRecordedExternally" else "internal",
            "administered_by": event.get("administered_by"),
            "recorded_by": event.get("recorded_by"),
            "lot_number": event.get("lot_number"),
            "expiration_date": event.get("expiration_date"),
            "site": event.get("site"),
        }
