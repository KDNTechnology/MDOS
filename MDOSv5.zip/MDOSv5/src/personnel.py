# src/personnel.py

from dataclasses import dataclass
from typing import Dict, Optional


@dataclass(frozen=True)
class User:
    """Represents a human operator of the ERP system."""
    username: str
    role: str          # "owner", "clerk", "auditor", "official", etc.
    full_name: str = ""
    active: bool = True


class PersonnelDirectory:
    """
    Minimal in-memory personnel directory.
    No dependencies. Can be wired into orchestrator later.
    """

    def __init__(self):
        self.users: Dict[str, User] = {}

    def add_user(self, username: str, role: str, full_name: str = ""):
        self.users[username] = User(username, role, full_name)

    def get_user(self, username: str) -> Optional[User]:
        return self.users.get(username)

    def list_users(self):
        return list(self.users.values())
