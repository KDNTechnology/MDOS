# src/visualization.py

class Visualization:
    """
    Visualization organ.
    Provides ASCII-based charts and summaries for:
      - cash flow
      - revenue vs expenses
      - event frequency
    """

    def _bar(self, value, scale=1):
        bars = int(value / scale)
        return "#" * max(bars, 0)

    def visualize_cash_flow(self):
        print("\n=== CASH FLOW (ASCII CHART) ===")

        inflow = sum(e.amount for e in self.log.events if e.type in ("cash_in", "invoice_paid"))
        outflow = sum(e.amount for e in self.log.events if e.type in ("cash_out", "bill_paid"))

        print(f"Inflow : {inflow:10} | {self._bar(inflow, scale=50)}")
        print(f"Outflow: {outflow:10} | {self._bar(outflow, scale=50)}")
        print(f"Net    : {inflow - outflow:10}")

    def visualize_event_frequency(self):
        print("\n=== EVENT FREQUENCY ===")

        freq = {}
        for e in self.log.events:
            freq[e.type] = freq.get(e.type, 0) + 1

        for k, v in freq.items():
            print(f"{k:20} {self._bar(v, scale=1)} ({v})")
