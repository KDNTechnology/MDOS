# dermatology_lesions.py
# MDOS Dermatology Lesion Tracking Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

DERMATOLOGY_SCHEMAS = {
    "LesionDocumented": {
        "required": [
            "patient_id",
            "timestamp",
            "documented_by",
            "lesion_id",
        ],
        "optional": [
            "location",
            "size_mm",
            "color",
            "shape",
            "characteristics",
            "notes",
        ],
    },

    "LesionUpdated": {
        "required": [
            "patient_id",
            "timestamp",
            "updated_by",
            "lesion_id",
        ],
        "optional": [
            "location",
            "size_mm",
            "color",
            "shape",
            "characteristics",
            "notes",
        ],
    },

    "LesionRemoved": {
        "required": [
            "patient_id",
            "timestamp",
            "removed_by",
            "lesion_id",
        ],
        "optional": ["reason"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class ActiveLesionsProjection:
    """
    patient_id → { lesion_id → latest lesion snapshot }
    """

    def __init__(self):
        self.state = defaultdict(dict)

    def apply(self, event: Dict[str, Any]):
        et = event["type"]
        pid = event["patient_id"]
        lid = event["lesion_id"]

        if et in ("LesionDocumented", "LesionUpdated"):
            snapshot = {
                "timestamp": event["timestamp"],
                "by": event.get("documented_by") or event.get("updated_by"),
            }

            for key in [
                "location",
                "size_mm",
                "color",
                "shape",
                "characteristics",
                "notes",
            ]:
                if key in event:
                    snapshot[key] = event[key]

            self.state[pid][lid] = snapshot

        elif et == "LesionRemoved":
            if lid in self.state[pid]:
                del self.state[pid][lid]


class LesionHistoryProjection:
    """
    patient_id → list of lesion events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] in (
            "LesionDocumented",
            "LesionUpdated",
            "LesionRemoved",
        ):
            pid = event["patient_id"]
            self.state[pid].append(event)
