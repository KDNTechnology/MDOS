# medication_reconciliation.py
# MDOS Medication Reconciliation Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

MED_REC_SCHEMAS = {
    "MedicationListImported": {
        "required": [
            "patient_id",
            "timestamp",
            "imported_by",
            "source",
            "medications",
        ],
        "optional": ["notes"],
    },

    "MedicationListReconciled": {
        "required": [
            "patient_id",
            "timestamp",
            "reconciled_by",
            "final_medications",
        ],
        "optional": ["notes"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class ImportedMedicationListsProjection:
    """
    patient_id → list of imported medication lists
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "MedicationListImported":
            pid = event["patient_id"]
            self.state[pid].append({
                "timestamp": event["timestamp"],
                "source": event["source"],
                "medications": event["medications"],
                "imported_by": event["imported_by"],
            })


class ReconciledMedicationListProjection:
    """
    patient_id → latest reconciled medication list
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "MedicationListReconciled":
            pid = event["patient_id"]
            self.state[pid] = {
                "timestamp": event["timestamp"],
                "reconciled_by": event["reconciled_by"],
                "final_medications": event["final_medications"],
            }
