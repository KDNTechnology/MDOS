# src/orderly/modules/module_template.py
# MDOS Clinical Module Template — crash‑proof, safe, minimal

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Safe helpers (never crash on bad input)
# ---------------------------------------------------------------------------

def safe_float(val):
    try:
        return float(val)
    except:
        return None

def safe_int(val):
    try:
        return int(val)
    except:
        return None


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

# NOTE:
# Replace <EventTypeName> with something like:
#   "VitalsRecorded"
#   "NeuroExamPerformed"
#   "GaitAssessmentPerformed"
#
# Replace <module> with:
#   "vitals"
#   "neuro"
#   "gait"
#
# This template is syntactically valid even before editing.

MODULE_SCHEMAS = {
    "TemplateEvent": {          # <-- safe placeholder
        "required": [
            "patient_id",
            "timestamp",
            "performed_by",
        ],
        "optional": [
            # Add optional fields here
            # "heart_rate",
            # "blood_pressure",
            # "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestTemplateProjection:
    """
    patient_id → latest event snapshot
    Crash‑proof: projection errors are contained.
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        try:
            if event["type"] != "TemplateEvent":
                return

            pid = event["patient_id"]

            snapshot = {
                "timestamp": event.get("timestamp"),
                "performed_by": event.get("performed_by"),
            }

            # Copy optional fields
            for key in MODULE_SCHEMAS["TemplateEvent"]["optional"]:
                if key in event:
                    snapshot[key] = event[key]

            self.state[pid] = snapshot

        except Exception as e:
            print(f"[TEMPLATE PROJECTION ERROR] {e}")


class TemplateHistoryProjection:
    """
    patient_id → list of events
    Crash‑proof: history always works.
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        try:
            if event["type"] == "TemplateEvent":
                pid = event["patient_id"]
                self.state[pid].append(event)
        except Exception as e:
            print(f"[TEMPLATE HISTORY ERROR] {e}")


# ---------------------------------------------------------------------------
# Registration with the world
# ---------------------------------------------------------------------------

def register(world):
    """
    Called automatically by world.load_modules().
    Crash‑proof: no module can kill the OS.
    """

    # Register schemas
    try:
        for name, schema in MODULE_SCHEMAS.items():
            world.add_schema(name, schema)
    except Exception as e:
        print(f"[TEMPLATE SCHEMA ERROR] {e}")

    # Register projections
    try:
        world.add_projection("latest_template", LatestTemplateProjection())
        world.add_projection("template_history", TemplateHistoryProjection())
    except Exception as e:
        print(f"[TEMPLATE PROJECTION REGISTER ERROR] {e}")

    # Register event type
    try:
        world.route_event_type("TemplateEvent")
    except Exception as e:
        print(f"[TEMPLATE EVENT TYPE ERROR] {e}")


# ---------------------------------------------------------------------------
# Interactive form (safe, optional)
# ---------------------------------------------------------------------------

def run_template_form(world):
    """
    Crash‑proof interactive form.
    Replace fields as needed.
    """

    print("\n--- Template Form ---")

    pid = input("Patient ID: ").strip()
    timestamp = input("Timestamp (YYYY-MM-DD HH:MM): ").strip()
    performed_by = input("Performed by: ").strip()

    event = {
        "type": "TemplateEvent",
        "patient_id": pid,
        "timestamp": timestamp,
        "performed_by": performed_by,
        "consent_given": True,
    }

    # Optional fields
    for field in MODULE_SCHEMAS["TemplateEvent"]["optional"]:
        val = input(f"{field}: ").strip()
        if val:
            # Try float, then int, then raw string
            f = safe_float(val)
            if f is not None:
                event[field] = f
                continue

            i = safe_int(val)
            if i is not None:
                event[field] = i
                continue

            event[field] = val

    print("\nGenerated event:")
    import json
    print(json.dumps(event, indent=2))

    confirm = input("Append to event log? (y/n): ").strip().lower()
    if confirm == "y":
        try:
            world.append(event)
            print("Event appended.\n")
        except Exception as e:
            print(f"[TEMPLATE APPEND ERROR] {e}")
    else:
        print("Cancelled.\n")


# ---------------------------------------------------------------------------
# Command registration (optional)
# ---------------------------------------------------------------------------

def register_commands(registry):
    """
    Register CLI commands for this module.
    Crash‑proof: errors are contained.
    """

    try:
        registry.register(
            name="template",
            handler=run_template_form,
            help_text="Enter a template event",
            category="clinical",
        )
    except Exception as e:
        print(f"[TEMPLATE COMMAND ERROR] {e}")
