# src/orderly/html_renderer.py

from pathlib import Path
import webbrowser

def render_patient_page(patient, output_path="patient.html"):
    html = f"""
    <html>
    <head>
        <title>Patient {patient['patient_id']}</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                background: #f5f5f5;
                padding: 20px;
            }}
            .card {{
                background: white;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0,0,0,0.1);
            }}
            h1 {{
                margin-top: 0;
            }}
        </style>
    </head>
    <body>
        <div class="card">
            <h1>Patient {patient['patient_id']}</h1>
            <p><strong>Name:</strong> {patient.get('name')}</p>
            <p><strong>DOB:</strong> {patient.get('dob')}</p>
            <p><strong>Sex:</strong> {patient.get('sex')}</p>
            <p><strong>Notes:</strong> {patient.get('notes')}</p>
        </div>
    </body>
    </html>
    """

    path = Path(output_path)
    path.write_text(html, encoding="utf-8")
    webbrowser.open(path.resolve().as_uri())
