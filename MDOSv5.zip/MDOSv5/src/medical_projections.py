# medical_projections.py
# Deterministic, rebuildable projections derived solely from events.
# No interpretation. No clinical judgment. Pure structural measurements.

from typing import Dict, Any, List, DefaultDict
from collections import defaultdict

# ---------------------------------------------------------------------------
# Base Projection Engine
# ---------------------------------------------------------------------------

class Projection:
    """
    Base class for deterministic projections.
    Each projection exposes:
        - apply(event)
        - state (dict)
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        raise NotImplementedError


# ---------------------------------------------------------------------------
# PATIENT TIMELINE
# ---------------------------------------------------------------------------

class PatientTimelineProjection(Projection):
    """
    A chronological list of all events for a patient.
    """

    def __init__(self):
        super().__init__()
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        patient_id = event.get("patient_id")
        if patient_id:
            self.state[patient_id].append(event)


# ---------------------------------------------------------------------------
# ENCOUNTERS
# ---------------------------------------------------------------------------

class EncounterProjection(Projection):
    """
    Tracks open/closed encounters and their metadata.
    """

    def __init__(self):
        super().__init__()
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        et = event.get("type")

        if et == "EncounterOpened":
            self.state[event["encounter_id"]] = {
                "patient_id": event["patient_id"],
                "opened_by": event["opened_by"],
                "timestamp_opened": event["timestamp"],
                "timestamp_closed": None,
                "closed_by": None,
                "notes": [],
            }

        elif et == "EncounterClosed":
            enc = self.state.get(event["encounter_id"])
            if enc:
                enc["timestamp_closed"] = event["timestamp"]
                enc["closed_by"] = event["closed_by"]

        elif et == "ClinicalNoteAdded":
            enc = self.state.get(event["encounter_id"])
            if enc:
                enc["notes"].append({
                    "timestamp": event["timestamp"],
                    "author": event["author"],
                    "note_type": event.get("note_type"),
                    "content": event.get("content"),
                })


# ---------------------------------------------------------------------------
# VITALS
# ---------------------------------------------------------------------------

class VitalsProjection(Projection):
    """
    Stores the latest vitals for each patient.
    """

    def __init__(self):
        super().__init__()
        self.state = defaultdict(dict)

    def apply(self, event: Dict[str, Any]):
        if event.get("type") == "VitalsRecorded":
            pid = event["patient_id"]
            self.state[pid] = {
                k: v for k, v in event.items()
                if k not in ("type", "encounter_id", "patient_id", "timestamp", "recorded_by")
                and v is not None
            }


# ---------------------------------------------------------------------------
# MEDICATIONS
# ---------------------------------------------------------------------------

class MedicationProjection(Projection):
    """
    Tracks active medications for each patient.
    """

    def __init__(self):
        super().__init__()
        self.state = defaultdict(dict)

    def apply(self, event: Dict[str, Any]):
        et = event.get("type")
        pid = event.get("patient_id")

        if et == "MedicationPrescribed":
            self.state[pid][event["medication_name"]] = {
                "dose": event.get("dose"),
                "route": event.get("route"),
                "frequency": event.get("frequency"),
                "duration": event.get("duration"),
                "timestamp": event["timestamp"],
                "prescribed_by": event["prescribed_by"],
            }

        elif et == "MedicationDiscontinued":
            meds = self.state.get(pid, {})
            if event["medication_name"] in meds:
                del meds[event["medication_name"]]


# ---------------------------------------------------------------------------
# DIAGNOSES
# ---------------------------------------------------------------------------

class DiagnosisProjection(Projection):
    """
    Tracks active diagnoses for each patient.
    """

    def __init__(self):
        super().__init__()
        self.state = defaultdict(set)

    def apply(self, event: Dict[str, Any]):
        et = event.get("type")
        pid = event.get("patient_id")

        if et == "DiagnosisAdded":
            self.state[pid].add(event["diagnosis_code"])

        elif et == "DiagnosisRemoved":
            if event["diagnosis_code"] in self.state[pid]:
                self.state[pid].remove(event["diagnosis_code"])


# ---------------------------------------------------------------------------
# LAB RESULTS
# ---------------------------------------------------------------------------

class LabProjection(Projection):
    """
    Stores the most recent lab results for each patient.
    """

    def __init__(self):
        super().__init__()
        self.state = defaultdict(dict)

    def apply(self, event: Dict[str, Any]):
        if event.get("type") == "LabResultReceived":
            pid = event["patient_id"]
            test = event["test_name"]
            self.state[pid][test] = {
                "result_value": event["result_value"],
                "units": event.get("units"),
                "reference_range": event.get("reference_range"),
                "timestamp": event["timestamp"],
                "resulted_by": event["resulted_by"],
            }


# ---------------------------------------------------------------------------
# IMAGING
# ---------------------------------------------------------------------------

class ImagingProjection(Projection):
    """
    Stores the most recent imaging results for each patient.
    """

    def __init__(self):
        super().__init__()
        self.state = defaultdict(dict)

    def apply(self, event: Dict[str, Any]):
        if event.get("type") == "ImagingResultReceived":
            pid = event["patient_id"]
            study = event["study_type"]
            self.state[pid][study] = {
                "result_summary": event["result_summary"],
                "timestamp": event["timestamp"],
                "resulted_by": event["resulted_by"],
            }


# ---------------------------------------------------------------------------
# SAFETY SIGNALS
# ---------------------------------------------------------------------------

class SafetySignalProjection(Projection):
    """
    Tracks active safety signals for each patient.
    Structural only. No interpretation.
    """

    def __init__(self):
        super().__init__()
        self.state = defaultdict(set)

    def apply(self, event: Dict[str, Any]):
        et = event.get("type")
        pid = event.get("patient_id")

        if et == "SafetySignalRaised":
            self.state[pid].add(event["signal_type"])

        elif et == "SafetySignalCleared":
            if event["signal_type"] in self.state[pid]:
                self.state[pid].remove(event["signal_type"])
