# musculoskeletal_assessment.py
# MDOS Musculoskeletal Assessment Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

MUSCULOSKELETAL_ASSESSMENT_SCHEMAS = {
    "MusculoskeletalAssessmentPerformed": {
        "required": [
            "patient_id",
            "timestamp",
            "performed_by",
        ],
        "optional": [
            "joint_exam",              # swelling, warmth, tenderness, deformity
            "range_of_motion",         # limited, full, painful
            "muscle_strength",         # 0–5 scale
            "gait_abnormalities",
            "back_exam",               # tenderness, spasm, straight-leg raise
            "posture",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestMusculoskeletalAssessmentProjection:
    """
    patient_id → latest musculoskeletal assessment snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "MusculoskeletalAssessmentPerformed":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "performed_by": event["performed_by"],
        }

        for key in [
            "joint_exam",
            "range_of_motion",
            "muscle_strength",
            "gait_abnormalities",
            "back_exam",
            "posture",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class MusculoskeletalAssessmentHistoryProjection:
    """
    patient_id → list of musculoskeletal assessments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "MusculoskeletalAssessmentPerformed":
            pid = event["patient_id"]
            self.state[pid].append(event)
