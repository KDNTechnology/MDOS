# sexual_health.py
# MDOS Sexual Health Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

SEXUAL_HEALTH_SCHEMAS = {
    "SexualHistoryUpdated": {
        "required": [
            "patient_id",
            "timestamp",
            "updated_by",
        ],
        "optional": [
            "partners",
            "contraception",
            "sti_history",
            "sti_screening_status",
            "pregnancy_risk",
            "sexual_practices",
            "notes",
        ],
    },

    "STIScreeningResultRecorded": {
        "required": [
            "patient_id",
            "timestamp",
            "recorded_by",
            "test_name",
            "result",
        ],
        "optional": ["notes"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class SexualHistoryProjection:
    """
    patient_id → latest sexual history snapshot
    """

    def __init__(self):
        self.state = defaultdict(dict)

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "SexualHistoryUpdated":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "updated_by": event["updated_by"],
        }

        for key in [
            "partners",
            "contraception",
            "sti_history",
            "sti_screening_status",
            "pregnancy_risk",
            "sexual_practices",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class STIScreeningHistoryProjection:
    """
    patient_id → list of STI screening results
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "STIScreeningResultRecorded":
            pid = event["patient_id"]
            self.state[pid].append(event)
