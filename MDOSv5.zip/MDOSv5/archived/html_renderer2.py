# src/orderly/html_renderer.py
# MDOS HTML Renderer — ephemeral, autodeleting patient pages

import tempfile
import webbrowser
import os
import time
from pathlib import Path


def build_patient_html(patient: dict) -> str:
    """
    Convert a patient dictionary into HTML.
    This is intentionally minimal — projections define the content.
    """

    name = patient.get("name", "Unknown")
    pid = patient.get("patient_id", "Unknown")
    dob = patient.get("dob", "Unknown")

    html = f"""
    <html>
    <head>
        <title>Patient {pid}</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                margin: 40px;
            }}
            h1 {{
                margin-bottom: 0;
            }}
            .section {{
                margin-top: 20px;
                padding: 10px;
                border: 1px solid #ccc;
                border-radius: 6px;
            }}
        </style>
    </head>
    <body>
        <h1>{name}</h1>
        <p><strong>ID:</strong> {pid}</p>
        <p><strong>DOB:</strong> {dob}</p>

        <div class="section">
            <h2>Raw Patient Data</h2>
            <pre>{patient}</pre>
        </div>
    </body>
    </html>
    """

    return html


def render_patient_page(patient: dict):
    """
    Render patient HTML to a temporary file, open it, and autodelete it.
    """

    html = build_patient_html(patient)

    # Create a temporary HTML file
    with tempfile.NamedTemporaryFile(delete=False, suffix=".html") as tmp:
        tmp.write(html.encode("utf-8"))
        path = Path(tmp.name)

    # Open in browser
    webbrowser.open(f"file://{path}")

    # Give the browser time to load the file
    time.sleep(2)

    # Autodelete the file
    try:
        os.remove(path)
    except Exception:
        # If the OS locks the file, fail silently — it will be cleaned later
        pass
