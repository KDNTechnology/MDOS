# hematology_assessment.py
# MDOS Hematology Assessment Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

HEMATOLOGY_ASSESSMENT_SCHEMAS = {
    "HematologyAssessmentPerformed": {
        "required": [
            "patient_id",
            "timestamp",
            "performed_by",
        ],
        "optional": [
            "bruising",                # none, mild, moderate, severe
            "bleeding_tendency",       # gums, nosebleeds, heavy menses
            "petechiae",
            "lymphadenopathy",         # cervical, axillary, inguinal
            "splenomegaly",
            "fatigue",
            "pallor",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestHematologyAssessmentProjection:
    """
    patient_id → latest hematology assessment snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "HematologyAssessmentPerformed":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "performed_by": event["performed_by"],
        }

        for key in [
            "bruising",
            "bleeding_tendency",
            "petechiae",
            "lymphadenopathy",
            "splenomegaly",
            "fatigue",
            "pallor",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class HematologyAssessmentHistoryProjection:
    """
    patient_id → list of hematology assessments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "HematologyAssessmentPerformed":
            pid = event["patient_id"]
            self.state[pid].append(event)
