# src/orderly/modules/vitals.py
# MDOS Vitals Module — crash‑proof, safe input, complete core vitals

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Safe helpers
# ---------------------------------------------------------------------------

def safe_float(val):
    try:
        return float(val)
    except:
        return None

def safe_int(val):
    try:
        return int(val)
    except:
        return None


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

VITALS_SCHEMAS = {
    "VitalsRecorded": {
        "required": [
            "patient_id",
            "timestamp",
            "performed_by",
        ],
        "optional": [
            "heart_rate",
            "respiratory_rate",
            "systolic_bp",
            "diastolic_bp",
            "temperature_c",
            "temperature_f",
            "oxygen_saturation",
            "pain_score",
            "height_cm",
            "weight_kg",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestVitalsProjection:
    """
    patient_id → latest vitals snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        try:
            if event["type"] != "VitalsRecorded":
                return

            pid = event["patient_id"]

            snapshot = {
                "timestamp": event.get("timestamp"),
                "performed_by": event.get("performed_by"),
            }

            for key in VITALS_SCHEMAS["VitalsRecorded"]["optional"]:
                if key in event:
                    snapshot[key] = event[key]

            self.state[pid] = snapshot

        except Exception as e:
            print(f"[VITALS PROJECTION ERROR] {e}")


class VitalsHistoryProjection:
    """
    patient_id → list of vitals events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        try:
            if event["type"] == "VitalsRecorded":
                pid = event["patient_id"]
                self.state[pid].append(event)
        except Exception as e:
            print(f"[VITALS HISTORY ERROR] {e}")


# ---------------------------------------------------------------------------
# Registration with the world
# ---------------------------------------------------------------------------

def register(world):
    """
    Called automatically by world.load_modules().
    """

    try:
        for name, schema in VITALS_SCHEMAS.items():
            world.add_schema(name, schema)
    except Exception as e:
        print(f"[VITALS SCHEMA ERROR] {e}")

    try:
        world.add_projection("latest_vitals", LatestVitalsProjection())
        world.add_projection("vitals_history", VitalsHistoryProjection())
    except Exception as e:
        print(f"[VITALS PROJECTION REGISTER ERROR] {e}")

    try:
        world.route_event_type("VitalsRecorded")
    except Exception as e:
        print(f"[VITALS EVENT TYPE ERROR] {e}")


# ---------------------------------------------------------------------------
# Interactive form (safe)
# ---------------------------------------------------------------------------

def run_vitals_form(world):
    """
    Crash‑proof vitals entry form.
    """

    print("\n--- Vitals Form ---")

    try:
        pid = input("Patient ID: ").strip()
        timestamp = input("Timestamp (YYYY-MM-DD HH:MM): ").strip()
        performed_by = input("Performed by: ").strip()

        hr = input("Heart rate (bpm): ").strip()
        rr = input("Respiratory rate (breaths/min): ").strip()
        sbp = input("Systolic BP: ").strip()
        dbp = input("Diastolic BP: ").strip()
        temp_c = input("Temperature (C): ").strip()
        temp_f = input("Temperature (F): ").strip()
        spo2 = input("Oxygen saturation (%): ").strip()
        pain = input("Pain score (0–10): ").strip()
        notes = input("Notes: ").strip()

        event = {
            "type": "VitalsRecorded",
            "patient_id": pid,
            "timestamp": timestamp,
            "performed_by": performed_by,
            "consent_given": True,
        }

        if safe_int(hr) is not None:
            event["heart_rate"] = safe_int(hr)

        if safe_int(rr) is not None:
            event["respiratory_rate"] = safe_int(rr)

        if safe_int(sbp) is not None:
            event["systolic_bp"] = safe_int(sbp)

        if safe_int(dbp) is not None:
            event["diastolic_bp"] = safe_int(dbp)

        if safe_float(temp_c) is not None:
            event["temperature_c"] = safe_float(temp_c)

        if safe_float(temp_f) is not None:
            event["temperature_f"] = safe_float(temp_f)

        if safe_int(spo2) is not None:
            event["oxygen_saturation"] = safe_int(spo2)

        if safe_int(pain) is not None:
            event["pain_score"] = safe_int(pain)

        if notes:
            event["notes"] = notes

        print("\nGenerated event:")
        import json
        print(json.dumps(event, indent=2))

        confirm = input("Append to event log? (y/n): ").strip().lower()
        if confirm == "y":
            try:
                world.append(event)
                print("Event appended.\n")
            except Exception as e:
                print(f"[VITALS APPEND ERROR] {e}")
        else:
            print("Cancelled.\n")

    except Exception as e:
        print(f"[VITALS FORM ERROR] {e}")


# ---------------------------------------------------------------------------
# Command registration
# ---------------------------------------------------------------------------

def register_commands(registry):
    try:
        registry.register(
            name="vitals",
            handler=run_vitals_form,
            help_text="Enter a vitals record",
            category="clinical",
        )
    except Exception as e:
        print(f"[VITALS COMMAND ERROR] {e}")
