# allergy_profile.py
# MDOS Allergy Profile Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

ALLERGY_PROFILE_SCHEMAS = {
    "AllergyRecorded": {
        "required": [
            "patient_id",
            "timestamp",
            "recorded_by",
            "allergen",
        ],
        "optional": [
            "reaction",            # rash, anaphylaxis, GI upset, etc.
            "severity",            # mild, moderate, severe
            "onset_date",
            "notes",
        ],
    },

    "AllergyUpdated": {
        "required": [
            "patient_id",
            "timestamp",
            "updated_by",
            "allergen",
        ],
        "optional": [
            "reaction",
            "severity",
            "notes",
        ],
    },

    "AllergyRemoved": {
        "required": [
            "patient_id",
            "timestamp",
            "removed_by",
            "allergen",
        ],
        "optional": ["notes"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class ActiveAllergiesProjection:
    """
    patient_id → { allergen → latest allergy snapshot }
    """

    def __init__(self):
        self.state = defaultdict(dict)

    def apply(self, event: Dict[str, Any]):
        et = event["type"]
        pid = event["patient_id"]
        allergen = event["allergen"]

        if et in ("AllergyRecorded", "AllergyUpdated"):
            snapshot = {
                "timestamp": event["timestamp"],
                "by": event.get("recorded_by") or event.get("updated_by"),
            }

            for key in ["reaction", "severity", "onset_date", "notes"]:
                if key in event:
                    snapshot[key] = event[key]

            self.state[pid][allergen] = snapshot

        elif et == "AllergyRemoved":
            if allergen in self.state[pid]:
                del self.state[pid][allergen]


class AllergyHistoryProjection:
    """
    patient_id → list of allergy-related events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] in ("AllergyRecorded", "AllergyUpdated", "AllergyRemoved"):
            pid = event["patient_id"]
            self.state[pid].append(event)
