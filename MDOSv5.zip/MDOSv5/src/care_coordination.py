# care_coordination.py
# MDOS Care Coordination Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

CARE_COORDINATION_SCHEMAS = {
    "ReferralCreated": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "referred_by",
            "target_specialty",
        ],
        "optional": ["reason", "notes"],
    },

    "FollowUpScheduled": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "scheduled_by",
            "follow_up_date",
        ],
        "optional": ["reason", "notes"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class ReferralStatusProjection:
    """
    patient_id → list of referrals
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event.get("type") == "ReferralCreated":
            pid = event["patient_id"]
            self.state[pid].append(event)


class FollowUpProjection:
    """
    patient_id → list of follow-up appointments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event.get("type") == "FollowUpScheduled":
            pid = event["patient_id"]
            self.state[pid].append(event)
