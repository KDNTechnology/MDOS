# family_history.py
# MDOS Family History Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

FAMILY_HISTORY_SCHEMAS = {
    "FamilyConditionRecorded": {
        "required": [
            "patient_id",
            "timestamp",
            "recorded_by",
            "condition_name",
        ],
        "optional": [
            "relationship",        # mother, father, sibling, child
            "age_at_diagnosis",
            "severity",
            "notes",
        ],
    },

    "FamilyConditionUpdated": {
        "required": [
            "patient_id",
            "timestamp",
            "updated_by",
            "condition_name",
        ],
        "optional": [
            "relationship",
            "age_at_diagnosis",
            "severity",
            "notes",
        ],
    },

    "FamilyConditionRemoved": {
        "required": [
            "patient_id",
            "timestamp",
            "removed_by",
            "condition_name",
        ],
        "optional": ["notes"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class FamilyHistoryProjection:
    """
    patient_id → { condition_name → latest family history snapshot }
    """

    def __init__(self):
        self.state = defaultdict(dict)

    def apply(self, event: Dict[str, Any]):
        et = event["type"]
        pid = event["patient_id"]
        cond = event["condition_name"]

        if et in ("FamilyConditionRecorded", "FamilyConditionUpdated"):
            snapshot = {
                "timestamp": event["timestamp"],
                "by": event.get("recorded_by") or event.get("updated_by"),
            }

            for key in [
                "relationship",
                "age_at_diagnosis",
                "severity",
                "notes",
            ]:
                if key in event:
                    snapshot[key] = event[key]

            self.state[pid][cond] = snapshot

        elif et == "FamilyConditionRemoved":
            if cond in self.state[pid]:
                del self.state[pid][cond]
