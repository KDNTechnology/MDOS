# wound_care.py
# MDOS Wound Care Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

WOUND_CARE_SCHEMAS = {
    "WoundDocumented": {
        "required": [
            "patient_id",
            "timestamp",
            "documented_by",
            "wound_id",
        ],
        "optional": [
            "location",
            "length_mm",
            "width_mm",
            "depth_mm",
            "stage",
            "exudate",
            "odor",
            "tissue_type",
            "notes",
        ],
    },

    "WoundUpdated": {
        "required": [
            "patient_id",
            "timestamp",
            "updated_by",
            "wound_id",
        ],
        "optional": [
            "location",
            "length_mm",
            "width_mm",
            "depth_mm",
            "stage",
            "exudate",
            "odor",
            "tissue_type",
            "notes",
        ],
    },

    "WoundHealed": {
        "required": [
            "patient_id",
            "timestamp",
            "healed_by",
            "wound_id",
        ],
        "optional": ["notes"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class ActiveWoundsProjection:
    """
    patient_id → { wound_id → latest wound snapshot }
    """

    def __init__(self):
        self.state = defaultdict(dict)

    def apply(self, event: Dict[str, Any]):
        et = event["type"]
        pid = event["patient_id"]
        wid = event["wound_id"]

        if et in ("WoundDocumented", "WoundUpdated"):
            snapshot = {
                "timestamp": event["timestamp"],
                "by": event.get("documented_by") or event.get("updated_by"),
            }

            for key in [
                "location",
                "length_mm",
                "width_mm",
                "depth_mm",
                "stage",
                "exudate",
                "odor",
                "tissue_type",
                "notes",
            ]:
                if key in event:
                    snapshot[key] = event[key]

            self.state[pid][wid] = snapshot

        elif et == "WoundHealed":
            if wid in self.state[pid]:
                del self.state[pid][wid]


class WoundHistoryProjection:
    """
    patient_id → list of wound care events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] in (
            "WoundDocumented",
            "WoundUpdated",
            "WoundHealed",
        ):
            pid = event["patient_id"]
            self.state[pid].append(event)
