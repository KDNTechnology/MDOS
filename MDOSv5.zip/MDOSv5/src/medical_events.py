# medical_events.py
# Constitutional MDOS event universe.
# Pure schemas. No interpretation. No clinical judgment.

from typing import Dict, Any, List

# ---------------------------------------------------------------------------
# Event Schema Registry (MDOS)
# ---------------------------------------------------------------------------

EVENT_SCHEMAS: Dict[str, Dict[str, Any]] = {

    # -----------------------------------------------------------------------
    # PATIENT IDENTITY & ADMINISTRATION
    # -----------------------------------------------------------------------
    "PatientRegistered": {
        "required": ["patient_id", "timestamp", "registered_by"],
        "optional": ["demographics", "contact_info", "notes"],
    },

    "PatientUpdated": {
        "required": ["patient_id", "timestamp", "updated_by"],
        "optional": ["demographics", "contact_info", "notes"],
    },

    "PatientArchived": {
        "required": ["patient_id", "timestamp", "archived_by"],
        "optional": ["reason"],
    },

    # -----------------------------------------------------------------------
    # ENCOUNTERS & CLINICAL WORKFLOW
    # -----------------------------------------------------------------------
    "EncounterOpened": {
        "required": ["encounter_id", "patient_id", "timestamp", "opened_by"],
        "optional": ["location", "reason"],
    },

    "EncounterClosed": {
        "required": ["encounter_id", "patient_id", "timestamp", "closed_by"],
        "optional": ["summary"],
    },

    "ClinicalNoteAdded": {
        "required": ["encounter_id", "patient_id", "timestamp", "author"],
        "optional": ["note_type", "content"],
    },

    # -----------------------------------------------------------------------
    # VITALS
    # -----------------------------------------------------------------------
    "VitalsRecorded": {
        "required": ["encounter_id", "patient_id", "timestamp", "recorded_by"],
        "optional": [
            "heart_rate",
            "blood_pressure",
            "respiratory_rate",
            "temperature",
            "oxygen_saturation",
            "height",
            "weight",
        ],
    },

    # -----------------------------------------------------------------------
    # MEDICATIONS
    # -----------------------------------------------------------------------
    "MedicationPrescribed": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "prescribed_by",
            "medication_name",
        ],
        "optional": ["dose", "route", "frequency", "duration", "notes"],
    },

    "MedicationDiscontinued": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "discontinued_by",
            "medication_name",
        ],
        "optional": ["reason"],
    },

    "MedicationAdministered": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "administered_by",
            "medication_name",
        ],
        "optional": ["dose", "route", "notes"],
    },

    # -----------------------------------------------------------------------
    # LABS
    # -----------------------------------------------------------------------
    "LabOrdered": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "ordered_by",
            "test_name",
        ],
        "optional": ["priority", "notes"],
    },

    "LabResultReceived": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "resulted_by",
            "test_name",
            "result_value",
        ],
        "optional": ["units", "reference_range", "notes"],
    },

    # -----------------------------------------------------------------------
    # IMAGING
    # -----------------------------------------------------------------------
    "ImagingOrdered": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "ordered_by",
            "study_type",
        ],
        "optional": ["reason", "notes"],
    },

    "ImagingResultReceived": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "resulted_by",
            "study_type",
            "result_summary",
        ],
        "optional": ["notes"],
    },

    # -----------------------------------------------------------------------
    # DIAGNOSES
    # -----------------------------------------------------------------------
    "DiagnosisAdded": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "added_by",
            "diagnosis_code",
        ],
        "optional": ["notes"],
    },

    "DiagnosisRemoved": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "removed_by",
            "diagnosis_code",
        ],
        "optional": ["reason"],
    },

    # -----------------------------------------------------------------------
    # PROCEDURES
    # -----------------------------------------------------------------------
    "ProcedurePerformed": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "performed_by",
            "procedure_code",
        ],
        "optional": ["notes"],
    },

    # -----------------------------------------------------------------------
    # CARE COORDINATION
    # -----------------------------------------------------------------------
    "ReferralCreated": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "referred_by",
            "target_specialty",
        ],
        "optional": ["reason", "notes"],
    },

    "FollowUpScheduled": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "scheduled_by",
            "follow_up_date",
        ],
        "optional": ["reason", "notes"],
    },

    # -----------------------------------------------------------------------
    # SAFETY SIGNALS (STRUCTURAL ONLY)
    # -----------------------------------------------------------------------
    "SafetySignalRaised": {
        "required": [
            "patient_id",
            "timestamp",
            "signal_type",
            "detected_by",
        ],
        "optional": ["related_event_id", "notes"],
    },

    "SafetySignalCleared": {
        "required": [
            "patient_id",
            "timestamp",
            "cleared_by",
            "signal_type",
        ],
        "optional": ["notes"],
    },
}

# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def validate_event(event: Dict[str, Any]) -> List[str]:
    """
    Structural validation only.
    Ensures required fields exist and no unknown fields appear.
    """
    event_type = event.get("type")
    if event_type not in EVENT_SCHEMAS:
        return [f"Unknown event type: {event_type}"]

    schema = EVENT_SCHEMAS[event_type]
    errors = []

    # Required fields
    for field in schema["required"]:
        if field not in event:
            errors.append(f"Missing required field: {field}")

    # Unknown fields
    allowed = set(schema["required"]) | set(schema.get("optional", [])) | {"type"}
    for field in event.keys():
        if field not in allowed:
            errors.append(f"Unknown field for {event_type}: {field}")

    return errors
