# imaging.py
# MDOS Imaging Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

IMAGING_SCHEMAS = {
    "ImagingOrdered": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "ordered_by",
            "study_type",
        ],
        "optional": ["reason", "notes"],
    },

    "ImagingResultReceived": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "resulted_by",
            "study_type",
            "result_summary",
        ],
        "optional": ["notes"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class ImagingResultsProjection:
    """
    patient_id → { study_type → latest imaging result }
    """

    def __init__(self):
        self.state = defaultdict(dict)

    def apply(self, event: Dict[str, Any]):
        if event.get("type") != "ImagingResultReceived":
            return

        pid = event["patient_id"]
        study = event["study_type"]

        self.state[pid][study] = {
            "result_summary": event["result_summary"],
            "timestamp": event["timestamp"],
            "resulted_by": event["resulted_by"],
        }


class ImagingHistoryProjection:
    """
    patient_id → list of all imaging events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event.get("type") in ("ImagingOrdered", "ImagingResultReceived"):
            pid = event["patient_id"]
            self.state[pid].append(event)
