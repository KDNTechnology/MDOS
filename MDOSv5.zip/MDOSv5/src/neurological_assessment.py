# neurological_assessment.py
# MDOS Neurological Assessment Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

NEUROLOGICAL_ASSESSMENT_SCHEMAS = {
    "NeurologicalAssessmentPerformed": {
        "required": [
            "patient_id",
            "timestamp",
            "performed_by",
        ],
        "optional": [
            "mental_status",            # alert, oriented, confused, lethargic
            "cranial_nerves",           # structured findings or summary
            "motor_strength",           # 0–5 scale per limb
            "sensory_exam",             # intact, diminished, absent
            "reflexes",                 # 0–4+ scale
            "coordination",             # finger-nose, heel-shin
            "gait",                     # normal, ataxic, shuffling
            "pronator_drift",
            "seizure_activity",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestNeurologicalAssessmentProjection:
    """
    patient_id → latest neurological assessment snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "NeurologicalAssessmentPerformed":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "performed_by": event["performed_by"],
        }

        for key in [
            "mental_status",
            "cranial_nerves",
            "motor_strength",
            "sensory_exam",
            "reflexes",
            "coordination",
            "gait",
            "pronator_drift",
            "seizure_activity",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class NeurologicalAssessmentHistoryProjection:
    """
    patient_id → list of neurological assessments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "NeurologicalAssessmentPerformed":
            pid = event["patient_id"]
            self.state[pid].append(event)
