# respiratory_assessment.py
# MDOS Respiratory Assessment Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

RESPIRATORY_ASSESSMENT_SCHEMAS = {
    "RespiratoryAssessmentPerformed": {
        "required": [
            "patient_id",
            "timestamp",
            "performed_by",
        ],
        "optional": [
            "respiratory_rate",
            "oxygen_saturation",
            "oxygen_device",
            "oxygen_flow_rate",
            "breath_sounds",          # wheezes, crackles, diminished, etc.
            "respiratory_effort",     # normal, labored, accessory muscles
            "cough",
            "sputum_characteristics",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestRespiratoryAssessmentProjection:
    """
    patient_id → latest respiratory assessment snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "RespiratoryAssessmentPerformed":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "performed_by": event["performed_by"],
        }

        for key in [
            "respiratory_rate",
            "oxygen_saturation",
            "oxygen_device",
            "oxygen_flow_rate",
            "breath_sounds",
            "respiratory_effort",
            "cough",
            "sputum_characteristics",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class RespiratoryAssessmentHistoryProjection:
    """
    patient_id → list of respiratory assessments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "RespiratoryAssessmentPerformed":
            pid = event["patient_id"]
            self.state[pid].append(event)
