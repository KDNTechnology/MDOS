# src/orderly/command_registry.py
# Central registry for all CLI commands across all modules.

from typing import Callable, Dict, Any


class CommandRegistry:
    """
    Stores all commands available to the buddy.
    Commands can be registered by modules or inferred automatically.
    """

    def __init__(self):
        # command_name → {handler, help, category}
        self._commands: Dict[str, Dict[str, Any]] = {}

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(
        self,
        name: str,
        handler: Callable,
        help_text: str = "",
        category: str = "general",
    ):
        """
        Register a single command.
        """
        self._commands[name] = {
            "handler": handler,
            "help": help_text,
            "category": category,
        }

    def bulk_register(self, commands: Dict[str, Dict[str, Any]]):
        """
        Register multiple commands at once.
        """
        for name, meta in commands.items():
            self.register(
                name=name,
                handler=meta["handler"],
                help_text=meta.get("help", ""),
                category=meta.get("category", "general"),
            )

    # ------------------------------------------------------------------
    # Lookup
    # ------------------------------------------------------------------

    def resolve(self, name: str):
        """
        Return the handler function for a command.
        """
        meta = self._commands.get(name)
        return meta["handler"] if meta else None

    def get_help(self, name: str):
        """
        Return help text for a command.
        """
        meta = self._commands.get(name)
        return meta["help"] if meta else ""

    def get_all(self):
        """
        Return all commands with metadata.
        """
        return self._commands

    def get_by_category(self, category: str):
        """
        Return commands filtered by category.
        """
        return {
            name: meta
            for name, meta in self._commands.items()
            if meta["category"] == category
        }

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def list_categories(self):
        """
        Return all categories in use.
        """
        return sorted({meta["category"] for meta in self._commands.values()})

    def list_commands(self):
        """
        Return all command names.
        """
        return sorted(self._commands.keys())
