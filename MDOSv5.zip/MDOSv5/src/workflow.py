# src/workflow.py

class WorkflowEngine:
    """
    Minimal workflow engine organ.
    Supports:
      - multi-step workflows
      - state transitions
      - workflow execution
      - workflow completion/failure
    """

    def __init__(self):
        self.workflows = {}      # workflow_id → workflow definition
        self.workflow_runs = {}  # run_id → state

    # ─────────────────────────────────────────────
    # Workflow definition
    # ─────────────────────────────────────────────
    def define_workflow(self, workflow_id, steps):
        """
        steps = [
            {"id": "start", "action": self.add_cash_in, "next": "verify"},
            {"id": "verify", "action": self.show_cash, "next": None},
        ]
        """
        self.workflows[workflow_id] = {s["id"]: s for s in steps}
        print(f"Workflow '{workflow_id}' defined.")

    # ─────────────────────────────────────────────
    # Workflow execution
    # ─────────────────────────────────────────────
    def start_workflow(self, workflow_id):
        if workflow_id not in self.workflows:
            print("Unknown workflow.")
            return

        run_id = f"run_{len(self.workflow_runs)+1}"
        self.workflow_runs[run_id] = {"workflow": workflow_id, "step": "start"}

        print(f"Workflow {workflow_id} started (run: {run_id})")
        self._run_step(run_id)

    def _run_step(self, run_id):
        run = self.workflow_runs[run_id]
        wf = self.workflows[run["workflow"]]
        step_id = run["step"]

        step = wf.get(step_id)
        if not step:
            print(f"Invalid step '{step_id}'")
            return

        # Execute action
        action = step.get("action")
        if action:
            action()

        # Move to next
        next_step = step.get("next")
        if next_step:
            run["step"] = next_step
            self._run_step(run_id)
        else:
            print(f"Workflow {run_id} completed.")
