# hearing_assessment.py
# MDOS Hearing Assessment Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

HEARING_ASSESSMENT_SCHEMAS = {
    "HearingAssessmentPerformed": {
        "required": [
            "patient_id",
            "timestamp",
            "performed_by",
        ],
        "optional": [
            "audiometry_left",
            "audiometry_right",
            "tympanometry_result",
            "hearing_loss_degree",
            "hearing_aids_used",
            "tinnitus_present",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestHearingAssessmentProjection:
    """
    patient_id → latest hearing assessment snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "HearingAssessmentPerformed":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "performed_by": event["performed_by"],
        }

        for key in [
            "audiometry_left",
            "audiometry_right",
            "tympanometry_result",
            "hearing_loss_degree",
            "hearing_aids_used",
            "tinnitus_present",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class HearingAssessmentHistoryProjection:
    """
    patient_id → list of hearing assessment events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "HearingAssessmentPerformed":
            pid = event["patient_id"]
            self.state[pid].append(event)
