# pain_assessment.py
# MDOS Pain Assessment Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

PAIN_ASSESSMENT_SCHEMAS = {
    "PainAssessmentRecorded": {
        "required": [
            "patient_id",
            "timestamp",
            "recorded_by",
            "pain_score",          # 0–10
        ],
        "optional": [
            "pain_location",
            "pain_quality",        # sharp, dull, burning, throbbing
            "pain_duration",
            "aggravating_factors",
            "relieving_factors",
            "functional_impact",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestPainAssessmentProjection:
    """
    patient_id → latest pain assessment snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "PainAssessmentRecorded":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "recorded_by": event["recorded_by"],
            "pain_score": event["pain_score"],
        }

        for key in [
            "pain_location",
            "pain_quality",
            "pain_duration",
            "aggravating_factors",
            "relieving_factors",
            "functional_impact",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class PainAssessmentHistoryProjection:
    """
    patient_id → list of pain assessments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "PainAssessmentRecorded":
            pid = event["patient_id"]
            self.state[pid].append(event)
