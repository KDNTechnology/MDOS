# geriatrics_assessment.py
# MDOS Geriatrics Assessment Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

GERIATRICS_ASSESSMENT_SCHEMAS = {
    "GeriatricsAssessmentPerformed": {
        "required": [
            "patient_id",
            "timestamp",
            "performed_by",
        ],
        "optional": [
            "frailty_score",             # clinical frailty scale
            "cognitive_status",          # intact, mild impairment, dementia
            "mobility_status",           # independent, walker, wheelchair
            "fall_risk",
            "polypharmacy_review",       # list or count of meds
            "continence_status",
            "nutrition_status",
            "social_support",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestGeriatricsAssessmentProjection:
    """
    patient_id → latest geriatrics assessment snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "GeriatricsAssessmentPerformed":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "performed_by": event["performed_by"],
        }

        for key in [
            "frailty_score",
            "cognitive_status",
            "mobility_status",
            "fall_risk",
            "polypharmacy_review",
            "continence_status",
            "nutrition_status",
            "social_support",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class GeriatricsAssessmentHistoryProjection:
    """
    patient_id → list of geriatrics assessments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "GeriatricsAssessmentPerformed":
            pid = event["patient_id"]
            self.state[pid].append(event)
