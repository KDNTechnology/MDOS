# rheumatology_assessment.py
# MDOS Rheumatology Assessment Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

RHEUMATOLOGY_ASSESSMENT_SCHEMAS = {
    "RheumatologyAssessmentPerformed": {
        "required": [
            "patient_id",
            "timestamp",
            "performed_by",
        ],
        "optional": [
            "joint_pain_distribution",     # symmetric, asymmetric, migratory
            "morning_stiffness_duration",  # minutes
            "swelling",                    # joints involved
            "warmth",
            "erythema",
            "range_of_motion_limitations",
            "autoimmune_markers",          # ANA, RF, CCP, etc.
            "fatigue",
            "rash",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestRheumatologyAssessmentProjection:
    """
    patient_id → latest rheumatology assessment snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "RheumatologyAssessmentPerformed":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "performed_by": event["performed_by"],
        }

        for key in [
            "joint_pain_distribution",
            "morning_stiffness_duration",
            "swelling",
            "warmth",
            "erythema",
            "range_of_motion_limitations",
            "autoimmune_markers",
            "fatigue",
            "rash",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class RheumatologyAssessmentHistoryProjection:
    """
    patient_id → list of rheumatology assessments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "RheumatologyAssessmentPerformed":
            pid = event["patient_id"]
            self.state[pid].append(event)
