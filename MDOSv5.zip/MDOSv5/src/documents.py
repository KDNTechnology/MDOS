# documents.py
# MDOS Document Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

DOCUMENT_SCHEMAS = {
    "DocumentScanned": {
        "required": [
            "document_id",
            "patient_id",
            "timestamp",
            "scanned_by",
        ],
        "optional": ["document_type", "notes"],
    },

    "MedicalRecordAmended": {
        "required": [
            "patient_id",
            "timestamp",
            "amended_by",
        ],
        "optional": ["amendment_text", "notes"],
    },

    "NoteSigned": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "signed_by",
        ],
        "optional": ["note_type"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class DocumentIndexProjection:
    """
    document_id → document metadata
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event.get("type") == "DocumentScanned":
            did = event["document_id"]
            self.state[did] = {
                "patient_id": event["patient_id"],
                "document_type": event.get("document_type"),
                "timestamp": event["timestamp"],
                "scanned_by": event["scanned_by"],
            }


class AmendmentHistoryProjection:
    """
    patient_id → list of amendments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event.get("type") == "MedicalRecordAmended":
            pid = event["patient_id"]
            self.state[pid].append(event)


class SignedNotesProjection:
    """
    patient_id → list of signed notes
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event.get("type") == "NoteSigned":
            pid = event["patient_id"]
            self.state[pid].append(event)
