# src/orderly/html_renderer.py
# MDOS HTML Renderer — secure, ephemeral, with Day/KDNT theme toggle

import tempfile
import webbrowser
import os
import time
from pathlib import Path


SECURE_JS = """
<script>
// Disable right-click
document.addEventListener("contextmenu", e => e.preventDefault());

// Disable text selection
document.addEventListener("selectstart", e => e.preventDefault());

// Disable drag
document.addEventListener("dragstart", e => e.preventDefault());

// Disable copy, cut, paste
document.addEventListener("copy", e => e.preventDefault());
document.addEventListener("cut", e => e.preventDefault());
document.addEventListener("paste", e => e.preventDefault());

// Disable keyboard shortcuts
document.addEventListener("keydown", function(e) {
    if ((e.ctrlKey && ["s","p","u"].includes(e.key.toLowerCase())) || e.key === "F12") {
        e.preventDefault();
        e.stopPropagation();
    }
});

// Disable printing
window.onbeforeprint = () => { throw "Printing disabled"; };

// Theme switching
function setTheme(mode) {
    document.body.classList.remove("theme-day", "theme-kdnt");
    document.body.classList.add("theme-" + mode);
}
</script>
"""


def build_patient_html(snapshot: dict) -> str:
    """
    Convert a unified patient snapshot into secure-mode HTML with Day/KDNT toggle.
    """

    genesis = snapshot.get("genesis", {})
    name = genesis.get("name", "Unknown")
    pid = genesis.get("patient_id", "Unknown")
    dob = genesis.get("dob", "Unknown")

    html = f"""
    <html>
    <head>
        <title>Patient {pid}</title>

        <style>
            body {{
                font-family: Arial, sans-serif;
                margin: 40px;
                user-select: none;
                transition: background 0.3s, color 0.3s;
            }}

            /* Day Theme */
            .theme-day {{
                background: #ffffff;
                color: #000000;
            }}

            /* KDNT Theme */
            .theme-kdnt {{
                background: #000000;
                color: #d4af37; /* gold */
            }}

            .header {{
                padding: 10px 0;
                font-size: 22px;
                font-weight: bold;
                margin-bottom: 20px;
                border-bottom: 2px solid #444;
            }}

            .theme-buttons button {{
                margin-right: 10px;
                padding: 6px 12px;
                border-radius: 6px;
                border: none;
                cursor: pointer;
                font-size: 14px;
            }}

            .section {{
                margin-top: 20px;
                padding: 10px;
                border: 1px solid #555;
                border-radius: 6px;
            }}

            pre {{
                background: rgba(255,255,255,0.05);
                padding: 10px;
                border-radius: 6px;
                overflow-x: auto;
            }}
        </style>

        {SECURE_JS}
    </head>

    <body class="theme-kdnt">

        <div class="header">
            Medical Doctor Operating Systems — Patient Viewer
        </div>

        <div class="theme-buttons">
            <button onclick="setTheme('day')">Day</button>
            <button onclick="setTheme('kdnt')">KDNT</button>
        </div>

        <h1>{name}</h1>
        <p><strong>ID:</strong> {pid}</p>
        <p><strong>DOB:</strong> {dob}</p>

        <div class="section">
            <h2>Raw Patient Data</h2>
            <pre>{genesis}</pre>

            <h2>Latest Vitals</h2>
            <pre>{snapshot.get("latest_vitals")}</pre>

            <h2>Vitals History</h2>
            <pre>{snapshot.get("vitals_history")}</pre>

            <h2>Latest Gait Assessment</h2>
            <pre>{snapshot.get("latest_gait")}</pre>

            <h2>Gait History</h2>
            <pre>{snapshot.get("gait_history")}</pre>

            <h2>Optional Vitals</h2>
            <pre>{snapshot.get("latest_optional_vitals")}</pre>
        </div>

    </body>
    </html>
    """

    return html


def render_patient_page(snapshot: dict):
    """
    Render patient HTML to a temporary file, open it, and autodelete it.
    """

    html = build_patient_html(snapshot)

    with tempfile.NamedTemporaryFile(delete=False, suffix=".html") as tmp:
        tmp.write(html.encode("utf-8"))
        path = Path(tmp.name)

    webbrowser.open(f"file://{path}")

    time.sleep(2)

    try:
        os.remove(path)
    except Exception:
        pass
