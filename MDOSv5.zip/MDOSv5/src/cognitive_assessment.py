# cognitive_assessment.py
# MDOS Cognitive Assessment Module (MMSE, MoCA, orientation, memory)
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

COGNITIVE_ASSESSMENT_SCHEMAS = {
    "CognitiveAssessmentPerformed": {
        "required": [
            "patient_id",
            "timestamp",
            "performed_by",
        ],
        "optional": [
            "mmse_score",
            "moca_score",
            "orientation",
            "memory_impairment",
            "executive_function",
            "language_issues",
            "visuospatial_issues",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestCognitiveAssessmentProjection:
    """
    patient_id → latest cognitive assessment snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "CognitiveAssessmentPerformed":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "performed_by": event["performed_by"],
        }

        for key in [
            "mmse_score",
            "moca_score",
            "orientation",
            "memory_impairment",
            "executive_function",
            "language_issues",
            "visuospatial_issues",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class CognitiveAssessmentHistoryProjection:
    """
    patient_id → list of cognitive assessments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "CognitiveAssessmentPerformed":
            pid = event["patient_id"]
            self.state[pid].append(event)
