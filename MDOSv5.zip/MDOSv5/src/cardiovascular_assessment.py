# cardiovascular_assessment.py
# MDOS Cardiovascular Assessment Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

CARDIOVASCULAR_ASSESSMENT_SCHEMAS = {
    "CardiovascularAssessmentPerformed": {
        "required": [
            "patient_id",
            "timestamp",
            "performed_by",
        ],
        "optional": [
            "heart_rate",
            "rhythm",                 # regular, irregular, afib, etc.
            "blood_pressure_systolic",
            "blood_pressure_diastolic",
            "heart_sounds",           # murmurs, gallops, rubs
            "perfusion",              # warm, cool, delayed cap refill
            "edema",                  # none, trace, pitting
            "jugular_venous_distention",
            "chest_pain",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestCardiovascularAssessmentProjection:
    """
    patient_id → latest cardiovascular assessment snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "CardiovascularAssessmentPerformed":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "performed_by": event["performed_by"],
        }

        for key in [
            "heart_rate",
            "rhythm",
            "blood_pressure_systolic",
            "blood_pressure_diastolic",
            "heart_sounds",
            "perfusion",
            "edema",
            "jugular_venous_distention",
            "chest_pain",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class CardiovascularAssessmentHistoryProjection:
    """
    patient_id → list of cardiovascular assessments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "CardiovascularAssessmentPerformed":
            pid = event["patient_id"]
            self.state[pid].append(event)
