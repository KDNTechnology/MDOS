# src/orderly/mdos_orchestrator.py

def register(world):
    # Startup checks become events
    world.append_system_event("StartupChecksPassed", {})

    # Plugins load as modules
    world.append_system_event("PluginsLoaded", {})
