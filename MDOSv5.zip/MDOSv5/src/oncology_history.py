# oncology_history.py
# MDOS Oncology History Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

ONCOLOGY_HISTORY_SCHEMAS = {
    "CancerDiagnosisRecorded": {
        "required": [
            "patient_id",
            "timestamp",
            "recorded_by",
            "cancer_type",
        ],
        "optional": [
            "stage",
            "grade",
            "biomarkers",
            "diagnosis_date",
            "notes",
        ],
    },

    "CancerTreatmentRecorded": {
        "required": [
            "patient_id",
            "timestamp",
            "recorded_by",
            "treatment_type",   # chemo, radiation, surgery, immunotherapy
        ],
        "optional": [
            "treatment_name",
            "start_date",
            "end_date",
            "response",
            "notes",
        ],
    },

    "CancerStatusUpdated": {
        "required": [
            "patient_id",
            "timestamp",
            "updated_by",
            "status",           # active, remission, recurrence, progression
        ],
        "optional": ["notes"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class OncologyHistoryProjection:
    """
    patient_id → structured oncology history
    """

    def __init__(self):
        self.state = defaultdict(lambda: {
            "diagnoses": [],
            "treatments": [],
            "status_history": [],
        })

    def apply(self, event: Dict[str, Any]):
        pid = event["patient_id"]
        et = event["type"]

        if et == "CancerDiagnosisRecorded":
            self.state[pid]["diagnoses"].append({
                "cancer_type": event["cancer_type"],
                "stage": event.get("stage"),
                "grade": event.get("grade"),
                "biomarkers": event.get("biomarkers"),
                "diagnosis_date": event.get("diagnosis_date"),
                "timestamp": event["timestamp"],
                "recorded_by": event["recorded_by"],
                "notes": event.get("notes"),
            })

        elif et == "CancerTreatmentRecorded":
            self.state[pid]["treatments"].append({
                "treatment_type": event["treatment_type"],
                "treatment_name": event.get("treatment_name"),
                "start_date": event.get("start_date"),
                "end_date": event.get("end_date"),
                "response": event.get("response"),
                "timestamp": event["timestamp"],
                "recorded_by": event["recorded_by"],
                "notes": event.get("notes"),
            })

        elif et == "CancerStatusUpdated":
            self.state[pid]["status_history"].append({
                "status": event["status"],
                "timestamp": event["timestamp"],
                "updated_by": event["updated_by"],
                "notes": event.get("notes"),
            })
