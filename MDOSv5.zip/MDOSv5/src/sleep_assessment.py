# sleep_assessment.py
# MDOS Sleep Assessment Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

SLEEP_ASSESSMENT_SCHEMAS = {
    "SleepAssessmentRecorded": {
        "required": [
            "patient_id",
            "timestamp",
            "recorded_by",
        ],
        "optional": [
            "sleep_hours",
            "sleep_quality",
            "insomnia_symptoms",
            "snoring",
            "apnea_risk",
            "daytime_fatigue",
            "sleep_medications",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestSleepAssessmentProjection:
    """
    patient_id → latest sleep assessment snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "SleepAssessmentRecorded":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "recorded_by": event["recorded_by"],
        }

        for key in [
            "sleep_hours",
            "sleep_quality",
            "insomnia_symptoms",
            "snoring",
            "apnea_risk",
            "daytime_fatigue",
            "sleep_medications",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class SleepAssessmentHistoryProjection:
    """
    patient_id → list of sleep assessments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "SleepAssessmentRecorded":
            pid = event["patient_id"]
            self.state[pid].append(event)
