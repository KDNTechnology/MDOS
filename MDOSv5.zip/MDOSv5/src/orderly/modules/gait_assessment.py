# src/orderly/modules/gait_assessment.py
# MDOS Gait Assessment Module — crash‑proof, payload‑aware

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Safe helpers
# ---------------------------------------------------------------------------

def safe_float(val):
    try:
        return float(val)
    except:
        return None


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

GAIT_ASSESSMENT_SCHEMAS = {
    "GaitAssessmentPerformed": {
        "required": [
            "patient_id",
            "timestamp",
            "performed_by",
        ],
        "optional": [
            "gait_speed_m_per_s",
            "timed_up_and_go_seconds",
            "balance_tests",
            "assistive_device_used",
            "gait_pattern",
            "fall_risk_level",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections (payload‑aware)
# ---------------------------------------------------------------------------

class LatestGaitAssessmentProjection:
    """
    patient_id → latest gait assessment snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        try:
            if event["type"] != "GaitAssessmentPerformed":
                return

            payload = event.get("payload", {})
            pid = payload.get("patient_id")
            if not pid:
                return

            snapshot = {
                "timestamp": payload.get("timestamp"),
                "performed_by": payload.get("performed_by"),
            }

            for key in GAIT_ASSESSMENT_SCHEMAS["GaitAssessmentPerformed"]["optional"]:
                if key in payload:
                    snapshot[key] = payload[key]

            self.state[pid] = snapshot

        except Exception as e:
            print(f"[GAIT PROJECTION ERROR] {e}")


class GaitAssessmentHistoryProjection:
    """
    patient_id → list of gait assessments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        try:
            if event["type"] != "GaitAssessmentPerformed":
                return

            payload = event.get("payload", {})
            pid = payload.get("patient_id")
            if not pid:
                return

            self.state[pid].append(payload)

        except Exception as e:
            print(f"[GAIT HISTORY ERROR] {e}")


# ---------------------------------------------------------------------------
# Registration with the world
# ---------------------------------------------------------------------------

def register(world):
    """
    Called automatically by world.load_modules().
    """

    try:
        for name, schema in GAIT_ASSESSMENT_SCHEMAS.items():
            world.add_schema(name, schema)
    except Exception as e:
        print(f"[GAIT SCHEMA ERROR] {e}")

    try:
        world.add_projection("latest_gait_assessment", LatestGaitAssessmentProjection())
        world.add_projection("gait_assessment_history", GaitAssessmentHistoryProjection())
    except Exception as e:
        print(f"[GAIT PROJECTION REGISTER ERROR] {e}")

    try:
        world.route_event_type("GaitAssessmentPerformed")
    except Exception as e:
        print(f"[GAIT EVENT TYPE ERROR] {e}")


# ---------------------------------------------------------------------------
# Interactive form (safe)
# ---------------------------------------------------------------------------

def run_gait_form(world):
    """
    Crash‑proof gait assessment entry form.
    """

    print("\n--- Gait Assessment Form ---")

    try:
        pid = input("Patient ID: ").strip()
        timestamp = input("Timestamp (YYYY-MM-DD HH:MM): ").strip()
        performed_by = input("Performed by: ").strip()

        gait_speed = input("Gait speed (m/s): ").strip()
        tug = input("Timed Up & Go (seconds): ").strip()
        balance = input("Balance tests (comma-separated): ").strip()
        device = input("Assistive device used: ").strip()
        pattern = input("Gait pattern: ").strip()
        fall_risk = input("Fall risk level: ").strip()
        notes = input("Notes: ").strip()

        event = {
            "type": "GaitAssessmentPerformed",
            "patient_id": pid,
            "timestamp": timestamp,
            "performed_by": performed_by,
            "consent_given": True,
        }

        speed_val = safe_float(gait_speed)
        if speed_val is not None:
            event["gait_speed_m_per_s"] = speed_val

        tug_val = safe_float(tug)
        if tug_val is not None:
            event["timed_up_and_go_seconds"] = tug_val

        if balance:
            event["balance_tests"] = [b.strip() for b in balance.split(",") if b.strip()]

        if device:
            event["assistive_device_used"] = device

        if pattern:
            event["gait_pattern"] = pattern

        if fall_risk:
            event["fall_risk_level"] = fall_risk

        if notes:
            event["notes"] = notes

        print("\nGenerated event:")
        import json
        print(json.dumps(event, indent=2))

        confirm = input("Append to event log? (y/n): ").strip().lower()
        if confirm == "y":
            try:
                world.append(event)
                print("Event appended.\n")
            except Exception as e:
                print(f"[GAIT APPEND ERROR] {e}")
        else:
            print("Cancelled.\n")

    except Exception as e:
        print(f"[GAIT FORM ERROR] {e}")


# ---------------------------------------------------------------------------
# Command registration
# ---------------------------------------------------------------------------

def register_commands(registry):
    try:
        registry.register(
            name="gait",
            handler=run_gait_form,
            help_text="Enter a gait assessment",
            category="clinical",
        )
    except Exception as e:
        print(f"[GAIT COMMAND ERROR] {e}")
