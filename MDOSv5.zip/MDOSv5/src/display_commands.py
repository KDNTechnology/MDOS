# src/display_commands.py

class DisplayCommands:
    """
    Display organ for:
      - Ledgers
      - Reports
      - Unified event viewer
      - Help panel
      - Log viewer

    Depends on orchestrator attributes:
      - cash_ledger, accrual_ledger, inventory_ledger
      - fund_ledger, budget_ledger, grant_ledger, project_ledger
      - ar_aging, ap_aging, pnl, balance_sheet, cash_flow
      - log
      - help_panel, registry
      - event_viewer
      - machine_store
      - gov_events
    """

    # ─────────────────────────────────────────────
    # Business ledger displays
    # ─────────────────────────────────────────────
    def show_cash(self): self.cash_ledger.show()
    def show_accrual(self): self.accrual_ledger.show()
    def show_inventory(self): self.inventory_ledger.show()

    # ─────────────────────────────────────────────
    # Governmental ledger displays
    # ─────────────────────────────────────────────
    def show_fund_ledger(self): self.fund_ledger.show()
    def show_budget_ledger(self): self.budget_ledger.show()
    def show_grant_ledger(self): self.grant_ledger.show()
    def show_project_ledger(self): self.project_ledger.show()

    # ─────────────────────────────────────────────
    # Reports
    # ─────────────────────────────────────────────
    def show_ar_aging(self): self.ar_aging.show()
    def show_ap_aging(self): self.ap_aging.show()
    def show_pnl(self): self.pnl.show()
    def show_balance_sheet(self): self.balance_sheet.show()
    def show_cash_flow(self): self.cash_flow.show()

    # ─────────────────────────────────────────────
    # System displays
    # ─────────────────────────────────────────────
    def show_log(self): self.log.dump()
    def show_help(self): self.help_panel.show(self.registry)

    # ─────────────────────────────────────────────
    # Unified event viewer
    # ─────────────────────────────────────────────
    def show_all_events(self):
        machine_events = self.machine_store.load_all()
        self.event_viewer.show_all(
            business=self.log.events,
            machine=machine_events,
            governmental=self.gov_events
        )

    def show_machine_events(self):
        machine_events = self.machine_store.load_all()
        self.event_viewer.show_machine(machine_events)

    def show_business_events(self):
        self.event_viewer.show_business(self.log.events)

    def show_governmental_events(self):
        self.event_viewer.show_governmental(self.gov_events)
