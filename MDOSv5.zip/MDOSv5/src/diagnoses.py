# diagnoses.py
# MDOS Diagnosis Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

DIAGNOSIS_SCHEMAS = {
    "DiagnosisAdded": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "added_by",
            "diagnosis_code",
        ],
        "optional": ["notes"],
    },

    "DiagnosisRemoved": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "removed_by",
            "diagnosis_code",
        ],
        "optional": ["reason"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class ActiveDiagnosesProjection:
    """
    patient_id → set of active diagnosis codes
    """

    def __init__(self):
        self.state = defaultdict(set)

    def apply(self, event: Dict[str, Any]):
        et = event.get("type")
        pid = event.get("patient_id")
        if not pid:
            return

        if et == "DiagnosisAdded":
            self.state[pid].add(event["diagnosis_code"])

        elif et == "DiagnosisRemoved":
            code = event["diagnosis_code"]
            if code in self.state[pid]:
                self.state[pid].remove(code)


class DiagnosisHistoryProjection:
    """
    patient_id → list of all diagnosis events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event.get("type") in ("DiagnosisAdded", "DiagnosisRemoved"):
            pid = event["patient_id"]
            self.state[pid].append(event)
