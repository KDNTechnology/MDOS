# staff_providers.py
# MDOS Staff & Provider Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

STAFF_PROVIDER_SCHEMAS = {
    "ProviderCredentialUpdated": {
        "required": [
            "provider_id",
            "timestamp",
            "updated_by",
        ],
        "optional": ["credentials", "notes"],
    },

    "StaffAssignedToPatient": {
        "required": [
            "patient_id",
            "provider_id",
            "timestamp",
            "assigned_by",
        ],
        "optional": ["role", "notes"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class ProviderDirectoryProjection:
    """
    provider_id → { credentials, last_updated }
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        et = event["type"]

        if et == "ProviderCredentialUpdated":
            pid = event["provider_id"]
            self.state[pid] = {
                "credentials": event.get("credentials"),
                "last_updated": event["timestamp"],
            }


class CareTeamProjection:
    """
    patient_id → list of assigned providers
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event.get("type") == "StaffAssignedToPatient":
            pid = event["patient_id"]
            self.state[pid].append(event)
