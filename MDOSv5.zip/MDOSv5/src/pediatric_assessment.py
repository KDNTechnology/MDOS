# pediatric_assessment.py
# MDOS Pediatric Assessment Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

PEDIATRIC_ASSESSMENT_SCHEMAS = {
    "PediatricAssessmentPerformed": {
        "required": [
            "patient_id",
            "timestamp",
            "performed_by",
        ],
        "optional": [
            "growth_percentiles",        # height, weight, head circumference
            "developmental_milestones",  # gross motor, fine motor, language, social
            "vaccination_status",
            "feeding_history",
            "sleep_patterns",
            "school_performance",
            "behavioral_concerns",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestPediatricAssessmentProjection:
    """
    patient_id → latest pediatric assessment snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "PediatricAssessmentPerformed":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "performed_by": event["performed_by"],
        }

        for key in [
            "growth_percentiles",
            "developmental_milestones",
            "vaccination_status",
            "feeding_history",
            "sleep_patterns",
            "school_performance",
            "behavioral_concerns",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class PediatricAssessmentHistoryProjection:
    """
    patient_id → list of pediatric assessments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "PediatricAssessmentPerformed":
            pid = event["patient_id"]
            self.state[pid].append(event)
