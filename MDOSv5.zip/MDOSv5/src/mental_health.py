# mental_health.py
# MDOS Mental Health Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

MENTAL_HEALTH_SCHEMAS = {
    "PsychHistoryUpdated": {
        "required": [
            "patient_id",
            "timestamp",
            "updated_by",
        ],
        "optional": [
            "diagnoses",
            "hospitalizations",
            "suicide_attempts",
            "self_harm_history",
            "therapy_history",
            "medication_history",
            "notes",
        ],
    },

    "PsychRiskFlagAdded": {
        "required": [
            "patient_id",
            "timestamp",
            "added_by",
            "flag_type",
        ],
        "optional": ["notes"],
    },

    "PsychRiskFlagRemoved": {
        "required": [
            "patient_id",
            "timestamp",
            "removed_by",
            "flag_type",
        ],
        "optional": ["reason"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class PsychHistoryProjection:
    """
    patient_id → latest structured psych history snapshot
    """

    def __init__(self):
        self.state = defaultdict(dict)

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "PsychHistoryUpdated":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "updated_by": event["updated_by"],
        }

        for key in [
            "diagnoses",
            "hospitalizations",
            "suicide_attempts",
            "self_harm_history",
            "therapy_history",
            "medication_history",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class PsychRiskFlagsProjection:
    """
    patient_id → set of active psych risk flags
    """

    def __init__(self):
        self.state = defaultdict(set)

    def apply(self, event: Dict[str, Any]):
        et = event["type"]
        pid = event["patient_id"]

        if et == "PsychRiskFlagAdded":
            self.state[pid].add(event["flag_type"])

        elif et == "PsychRiskFlagRemoved":
            flag = event["flag_type"]
            if flag in self.state[pid]:
                self.state[pid].remove(flag)
