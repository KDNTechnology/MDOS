# substance_use_screening.py
# MDOS Substance Use Screening Module (AUDIT-C, DAST, etc.)
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

SUBSTANCE_USE_SCHEMAS = {
    "SubstanceUseScreeningCompleted": {
        "required": [
            "patient_id",
            "timestamp",
            "screened_by",
            "screening_type",   # AUDIT-C, DAST-10, CRAFFT, etc.
        ],
        "optional": [
            "score",
            "risk_level",
            "substances_reported",
            "frequency",
            "notes",
        ],
    },

    "SubstanceUseFlagAdded": {
        "required": [
            "patient_id",
            "timestamp",
            "added_by",
            "flag_type",
        ],
        "optional": ["notes"],
    },

    "SubstanceUseFlagRemoved": {
        "required": [
            "patient_id",
            "timestamp",
            "removed_by",
            "flag_type",
        ],
        "optional": ["reason"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class SubstanceUseScreeningHistoryProjection:
    """
    patient_id → list of substance use screenings
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "SubstanceUseScreeningCompleted":
            pid = event["patient_id"]
            self.state[pid].append(event)


class SubstanceUseFlagsProjection:
    """
    patient_id → set of active substance use flags
    """

    def __init__(self):
        self.state = defaultdict(set)

    def apply(self, event: Dict[str, Any]):
        et = event["type"]
        pid = event["patient_id"]

        if et == "SubstanceUseFlagAdded":
            self.state[pid].add(event["flag_type"])

        elif et == "SubstanceUseFlagRemoved":
            flag = event["flag_type"]
            if flag in self.state[pid]:
                self.state[pid].remove(flag)
