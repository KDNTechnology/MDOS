# psychiatric_symptom_tracking.py
# MDOS Psychiatric Symptom Tracking Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

PSYCHIATRIC_SYMPTOM_SCHEMAS = {
    "PsychiatricSymptomsRecorded": {
        "required": [
            "patient_id",
            "timestamp",
            "recorded_by",
        ],
        "optional": [
            "mood",                     # depressed, elevated, irritable, stable
            "anxiety_level",            # none, mild, moderate, severe
            "psychosis_symptoms",       # hallucinations, delusions
            "behavioral_changes",       # agitation, withdrawal
            "sleep_changes",
            "appetite_changes",
            "functioning_level",        # work, social, self-care
            "notes",
        ],
    },
}
    

# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestPsychiatricSymptomsProjection:
    """
    patient_id → latest psychiatric symptom snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "PsychiatricSymptomsRecorded":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "recorded_by": event["recorded_by"],
        }

        for key in [
            "mood",
            "anxiety_level",
            "psychosis_symptoms",
            "behavioral_changes",
            "sleep_changes",
            "appetite_changes",
            "functioning_level",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class PsychiatricSymptomsHistoryProjection:
    """
    patient_id → list of psychiatric symptom tracking events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "PsychiatricSymptomsRecorded":
            pid = event["patient_id"]
            self.state[pid].append(event)
