# immunologic_assessment.py
# MDOS Immunologic Assessment Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

IMMUNOLOGIC_ASSESSMENT_SCHEMAS = {
    "ImmunologicAssessmentPerformed": {
        "required": [
            "patient_id",
            "timestamp",
            "performed_by",
        ],
        "optional": [
            "autoimmune_symptoms",        # joint pain, rash, fatigue, etc.
            "flare_status",               # active flare, stable, improving
            "immunosuppressive_therapy",  # steroids, biologics, DMARDs
            "infection_risk",
            "lymph_node_findings",
            "rash_characteristics",
            "notes",
        ],
    },
}
    

# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestImmunologicAssessmentProjection:
    """
    patient_id → latest immunologic assessment snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "ImmunologicAssessmentPerformed":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "performed_by": event["performed_by"],
        }

        for key in [
            "autoimmune_symptoms",
            "flare_status",
            "immunosuppressive_therapy",
            "infection_risk",
            "lymph_node_findings",
            "rash_characteristics",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class ImmunologicAssessmentHistoryProjection:
    """
    patient_id → list of immunologic assessments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "ImmunologicAssessmentPerformed":
            pid = event["patient_id"]
            self.state[pid].append(event)
