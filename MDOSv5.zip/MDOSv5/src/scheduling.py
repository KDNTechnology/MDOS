# scheduling.py
# MDOS Scheduling Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

SCHEDULING_SCHEMAS = {
    "AppointmentScheduled": {
        "required": [
            "appointment_id",
            "patient_id",
            "timestamp",
            "scheduled_by",
            "appointment_time",
        ],
        "optional": ["reason", "notes"],
    },

    "AppointmentRescheduled": {
        "required": [
            "appointment_id",
            "patient_id",
            "timestamp",
            "rescheduled_by",
            "new_time",
        ],
        "optional": ["reason"],
    },

    "AppointmentCancelled": {
        "required": [
            "appointment_id",
            "patient_id",
            "timestamp",
            "cancelled_by",
        ],
        "optional": ["reason"],
    },

    "AppointmentCheckedIn": {
        "required": [
            "appointment_id",
            "patient_id",
            "timestamp",
            "checked_in_by",
        ],
        "optional": [],
    },

    "AppointmentCheckedOut": {
        "required": [
            "appointment_id",
            "patient_id",
            "timestamp",
            "checked_out_by",
        ],
        "optional": [],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class AppointmentCalendarProjection:
    """
    appointment_id → appointment details
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        et = event["type"]
        aid = event.get("appointment_id")
        if not aid:
            return

        if et == "AppointmentScheduled":
            self.state[aid] = {
                "patient_id": event["patient_id"],
                "appointment_time": event["appointment_time"],
                "status": "scheduled",
                "last_updated": event["timestamp"],
            }

        elif et == "AppointmentRescheduled":
            if aid in self.state:
                self.state[aid]["appointment_time"] = event["new_time"]
                self.state[aid]["status"] = "rescheduled"
                self.state[aid]["last_updated"] = event["timestamp"]

        elif et == "AppointmentCancelled":
            if aid in self.state:
                self.state[aid]["status"] = "cancelled"
                self.state[aid]["last_updated"] = event["timestamp"]

        elif et == "AppointmentCheckedIn":
            if aid in self.state:
                self.state[aid]["status"] = "checked_in"
                self.state[aid]["last_updated"] = event["timestamp"]

        elif et == "AppointmentCheckedOut":
            if aid in self.state:
                self.state[aid]["status"] = "checked_out"
                self.state[aid]["last_updated"] = event["timestamp"]


class DailyScheduleProjection:
    """
    patient_id → list of appointment events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event.get("type") in (
            "AppointmentScheduled",
            "AppointmentRescheduled",
            "AppointmentCancelled",
            "AppointmentCheckedIn",
            "AppointmentCheckedOut",
        ):
            pid = event["patient_id"]
            self.state[pid].append(event)
