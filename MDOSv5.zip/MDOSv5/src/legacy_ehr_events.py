# legacy_ehr_events.py
# Legacy EHR / Practice Management / HL7 event taxonomy.
# Not part of MDOS physics. Not validated. Not routed.
# Reference-only. For future constitutional scope expansion.

from typing import Literal

LegacyEHREventType = Literal[
    # Patient lifecycle
    "patient_registered",
    "patient_updated",
    "patient_deactivated",
    "patient_merged",
    "patient_consent_obtained",
    "patient_consent_revoked",
    "patient_portal_access_granted",
    "patient_portal_login",

    # Scheduling
    "appointment_scheduled",
    "appointment_confirmed",
    "appointment_rescheduled",
    "appointment_cancelled",
    "appointment_no_show",
    "appointment_checked_in",
    "appointment_checked_out",
    "waitlist_added",
    "waitlist_removed",
    "reminder_sent",

    # Encounters
    "encounter_started",
    "encounter_completed",
    "vital_signs_recorded",
    "chief_complaint_documented",
    "history_of_present_illness_updated",
    "review_of_systems_completed",
    "physical_exam_performed",
    "assessment_documented",
    "plan_of_care_created",
    "follow_up_scheduled",
    "telehealth_session_initiated",
    "telehealth_session_ended",

    # Diagnostics
    "lab_order_placed",
    "lab_sample_collected",
    "lab_results_received",
    "lab_results_reviewed",
    "imaging_order_placed",
    "imaging_study_performed",
    "imaging_report_generated",
    "imaging_report_reviewed",
    "diagnostic_test_ordered",
    "diagnostic_test_completed",
    "biopsy_taken",
    "pathology_report_issued",
    "allergy_test_performed",

    # Treatments
    "medication_prescribed",
    "medication_dispensed",
    "medication_administered",
    "medication_refill_requested",
    "medication_refill_approved",
    "procedure_scheduled",
    "procedure_performed",
    "surgery_scheduled",
    "surgery_completed",
    "injection_given",
    "vaccination_administered",
    "therapy_session_conducted",
    "wound_care_performed",
    "rehabilitation_plan_started",

    # Pharmacy
    "prescription_sent_to_pharmacy",
    "prescription_filled",
    "medication_reconciliation_performed",
    "adverse_drug_event_reported",
    "drug_interaction_checked",
    "controlled_substance_prescribed",

    # Billing
    "charge_posted",
    "claim_submitted",
    "claim_approved",
    "claim_denied",
    "claim_appealed",
    "payment_posted",
    "adjustment_applied",
    "write_off_approved",
    "copay_collected",
    "prior_authorization_requested",
    "prior_authorization_approved",
    "eligibility_verified",

    # Compliance
    "hipaa_consent_signed",
    "privacy_notice_acknowledged",
    "data_breach_detected",
    "audit_log_entry_created",
    "release_of_information_authorized",
    "release_of_information_sent",
    "phi_access_logged",
    "compliance_training_completed",

    # Quality
    "quality_measure_reported",
    "outcome_measure_recorded",
    "patient_satisfaction_survey_sent",
    "patient_satisfaction_survey_completed",
    "adverse_event_reported",
    "near_miss_documented",
    "root_cause_analysis_performed",

    # Operations
    "provider_credential_updated",
    "staff_assigned_to_patient",
    "referral_sent",
    "referral_received",
    "consultation_requested",
    "consultation_provided",
    "medical_record_amended",
    "document_scanned",
    "note_signed",
    "order_set_applied",
    "protocol_initiated",

    # Emergency
    "emergency_admission",
    "code_blue_called",
    "resuscitation_attempted",
    "intubation_performed",
    "defibrillation_administered",
    "transfer_to_icu",
    "discharge_from_er",

    # Chronic care
    "care_plan_created",
    "care_plan_updated",
    "population_health_screening_performed",
    "risk_assessment_completed",
    "preventive_service_recommended",
    "health_coaching_session_held",

    # End-of-life
    "discharge_summary_created",
    "discharge_instructions_given",
    "advance_directive_documented",
    "do_not_resuscitate_order_issued",
    "palliative_care_consult_requested",
    "hospice_referral_made",
    "death_certificate_issued",

    # Interoperability
    "hl7_message_received",
    "fhir_resource_created",
    "ccd_exchanged",
    "integration_error_logged",
]
