# obstetrics_history.py
# MDOS Obstetric History Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

OB_HISTORY_SCHEMAS = {
    "PregnancyRecorded": {
        "required": [
            "patient_id",
            "timestamp",
            "recorded_by",
            "pregnancy_number",
        ],
        "optional": [
            "year",
            "outcome",
            "gestational_age",
            "complications",
            "notes",
        ],
    },

    "PregnancyOutcomeUpdated": {
        "required": [
            "patient_id",
            "timestamp",
            "updated_by",
            "pregnancy_number",
            "outcome",
        ],
        "optional": ["notes"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class ObstetricHistoryProjection:
    """
    patient_id → list of pregnancies with outcomes
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        et = event["type"]
        pid = event["patient_id"]

        if et == "PregnancyRecorded":
            self.state[pid].append({
                "pregnancy_number": event["pregnancy_number"],
                "year": event.get("year"),
                "outcome": event.get("outcome"),
                "gestational_age": event.get("gestational_age"),
                "complications": event.get("complications"),
                "timestamp": event["timestamp"],
                "recorded_by": event["recorded_by"],
                "notes": event.get("notes"),
            })

        elif et == "PregnancyOutcomeUpdated":
            for entry in self.state[pid]:
                if entry["pregnancy_number"] == event["pregnancy_number"]:
                    entry["outcome"] = event["outcome"]
                    entry["timestamp"] = event["timestamp"]
                    entry["updated_by"] = event["updated_by"]
                    entry["notes"] = event.get("notes")
