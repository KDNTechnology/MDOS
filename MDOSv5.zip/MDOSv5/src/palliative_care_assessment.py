# palliative_care_assessment.py
# MDOS Palliative Care Assessment Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

PALLIATIVE_CARE_ASSESSMENT_SCHEMAS = {
    "PalliativeCareAssessmentPerformed": {
        "required": [
            "patient_id",
            "timestamp",
            "performed_by",
        ],
        "optional": [
            "pain_level",
            "dyspnea",
            "nausea",
            "anxiety",
            "depression",
            "fatigue",
            "goals_of_care",
            "advance_care_planning_status",
            "comfort_measures",
            "spiritual_needs",
            "family_support_needs",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestPalliativeCareAssessmentProjection:
    """
    patient_id → latest palliative care assessment snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "PalliativeCareAssessmentPerformed":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "performed_by": event["performed_by"],
        }

        for key in [
            "pain_level",
            "dyspnea",
            "nausea",
            "anxiety",
            "depression",
            "fatigue",
            "goals_of_care",
            "advance_care_planning_status",
            "comfort_measures",
            "spiritual_needs",
            "family_support_needs",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class PalliativeCareAssessmentHistoryProjection:
    """
    patient_id → list of palliative care assessments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "PalliativeCareAssessmentPerformed":
            pid = event["patient_id"]
            self.state[pid].append(event)
