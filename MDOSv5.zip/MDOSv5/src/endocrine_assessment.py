# endocrine_assessment.py
# MDOS Endocrine Assessment Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

ENDOCRINE_ASSESSMENT_SCHEMAS = {
    "EndocrineAssessmentPerformed": {
        "required": [
            "patient_id",
            "timestamp",
            "performed_by",
        ],
        "optional": [
            "thyroid_exam",            # goiter, nodules, tenderness
            "diabetes_symptoms",       # polyuria, polydipsia, weight loss
            "hypoglycemia_symptoms",
            "cushingoid_features",
            "acromegaly_features",
            "temperature_intolerance",
            "skin_changes",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestEndocrineAssessmentProjection:
    """
    patient_id → latest endocrine assessment snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "EndocrineAssessmentPerformed":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "performed_by": event["performed_by"],
        }

        for key in [
            "thyroid_exam",
            "diabetes_symptoms",
            "hypoglycemia_symptoms",
            "cushingoid_features",
            "acromegaly_features",
            "temperature_intolerance",
            "skin_changes",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class EndocrineAssessmentHistoryProjection:
    """
    patient_id → list of endocrine assessments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "EndocrineAssessmentPerformed":
            pid = event["patient_id"]
            self.state[pid].append(event)
