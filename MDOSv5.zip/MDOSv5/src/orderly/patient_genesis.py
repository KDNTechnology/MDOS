# src/orderly/patient_genesis.py
# Patient Genesis Module — creates and tracks core patient identity
from typing import Dict, Any
from collections import defaultdict

# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------

PATIENT_SCHEMAS = {
    "PatientGenesis": {
        "required": [
            "patient_id",
            "name",
            "dob",          # ISO date string
            "created_by",   # clinician / system user
        ],
        "optional": [
            "sex",
            "gender_identity",
            "pronouns",
            "contact_phone",
            "contact_email",
            "address",
            "notes",
        ],
    },
}

# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class PatientDirectoryProjection:
    """
    patient_id → core patient snapshot (latest genesis-like info)
    """

    def __init__(self):
        self.state: Dict[str, Dict[str, Any]] = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "PatientGenesis":
            return

        payload = event.get("payload", {})
        pid = payload["patient_id"]

        snapshot = {
            "patient_id": pid,
            "name": payload["name"],
            "dob": payload["dob"],
            "created_by": payload["created_by"],
            "created_at": event["timestamp"],
        }

        for key in [
            "sex",
            "gender_identity",
            "pronouns",
            "contact_phone",
            "contact_email",
            "address",
            "notes",
        ]:
            if key in payload:
                snapshot[key] = payload[key]

        self.state[pid] = snapshot


class PatientGenesisHistoryProjection:
    """
    patient_id → list of all PatientGenesis events (in order)
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "PatientGenesis":
            return

        payload = event.get("payload", {})
        pid = payload["patient_id"]
        self.state[pid].append(event)


# ---------------------------------------------------------------------------
# Helper: build a PatientGenesis event
# ---------------------------------------------------------------------------

def build_patient_genesis_event(
    patient_id: str,
    name: str,
    dob: str,
    created_by: str,
    **extra: Any,
) -> Dict[str, Any]:
    """
    Returns a bare PatientGenesis event dict.
    The event_log.append_event(...) will fill id/timestamp/hash.
    """
    payload: Dict[str, Any] = {
        "patient_id": patient_id,
        "name": name,
        "dob": dob,
        "created_by": created_by,
    }
    payload.update(extra)

    return {
        "type": "PatientGenesis",
        "payload": payload,
    }


# ---------------------------------------------------------------------------
# Omega wiring
# ---------------------------------------------------------------------------

def register(world):
    """
    Called by Omega on boot.
    Wires schemas + projections into the world.
    """
    # Schemas for validation
    world.schemas.update(PATIENT_SCHEMAS)

    # Projections
    world.add_projection("patient_directory", PatientDirectoryProjection())
    world.add_projection("patient_genesis_history", PatientGenesisHistoryProjection())

    # Let the router know we care about this event type
    world.route_event_type("PatientGenesis")
