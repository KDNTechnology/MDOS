# src/orderly/modules/<module_name>.py
# MDOS Clinical Module Template
# Replace <module> with your module name (e.g., gait, vitals, neuro)

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

MODULE_SCHEMAS = {
    "<EventTypeName>": {
        "required": [
            # "patient_id",
            # "timestamp",
            # "performed_by",
        ],
        "optional": [
            # "field1",
            # "field2",
            # "field3",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestModuleProjection:
    """
    patient_id → latest <module> snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "<EventTypeName>":
            return

        pid = event["patient_id"]

        snapshot = {
            # "timestamp": event["timestamp"],
            # "performed_by": event["performed_by"],
        }

        # Copy optional fields if present
        for key in MODULE_SCHEMAS["<EventTypeName>"]["optional"]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class ModuleHistoryProjection:
    """
    patient_id → list of <module> events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "<EventTypeName>":
            pid = event["patient_id"]
            self.state[pid].append(event)


# ---------------------------------------------------------------------------
# Registration with the world
# ---------------------------------------------------------------------------

def register(world):
    """
    Called automatically by world.load_modules().
    Registers schemas, projections, and event types.
    """

    # Register schemas
    for name, schema in MODULE_SCHEMAS.items():
        world.add_schema(name, schema)

    # Register projections
    world.add_projection("latest_<module>", LatestModuleProjection())
    world.add_projection("<module>_history", ModuleHistoryProjection())

    # Register event type
    world.route_event_type("<EventTypeName>")


# ---------------------------------------------------------------------------
# Optional: Interactive form for the buddy
# ---------------------------------------------------------------------------

def run_<module>_form(world):
    """
    Interactive form for entering <module> events.
    """

    print("\n--- <Module> Form ---")
    pid = input("Patient ID: ").strip()
    timestamp = input("Timestamp (YYYY-MM-DD HH:MM): ").strip()
    performed_by = input("Performed by: ").strip()

    event = {
        "type": "<EventTypeName>",
        "patient_id": pid,
        "timestamp": timestamp,
        "performed_by": performed_by,
        "consent_given": True,
    }

    # Optional fields
    for field in MODULE_SCHEMAS["<EventTypeName>"]["optional"]:
        val = input(f"{field}: ").strip()
        if val:
            event[field] = val

    print("\nGenerated event:")
    import json
    print(json.dumps(event, indent=2))

    confirm = input("Append to event log? (y/n): ").strip().lower()
    if confirm == "y":
        world.append(event)
        print("Event appended.\n")
    else:
        print("Cancelled.\n")


# ---------------------------------------------------------------------------
# Optional: Command registration for the buddy
# ---------------------------------------------------------------------------

def register_commands(registry):
    """
    Register CLI commands for this module.
    """

    registry.register(
        name="<module>",
        handler=run_<module>_form,
        help_text="Enter a <module> event",
        category="clinical",
    )
