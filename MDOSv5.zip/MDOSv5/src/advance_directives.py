# advance_directives.py
# MDOS Advance Directives Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

ADVANCE_DIRECTIVES_SCHEMAS = {
    "AdvanceDirectiveAdded": {
        "required": [
            "patient_id",
            "timestamp",
            "added_by",
            "directive_type",
        ],
        "optional": ["details", "notes"],
    },

    "AdvanceDirectiveUpdated": {
        "required": [
            "patient_id",
            "timestamp",
            "updated_by",
            "directive_type",
        ],
        "optional": ["details", "notes"],
    },

    "AdvanceDirectiveRevoked": {
        "required": [
            "patient_id",
            "timestamp",
            "revoked_by",
            "directive_type",
        ],
        "optional": ["reason"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class AdvanceDirectivesProjection:
    """
    patient_id → { directive_type → latest directive }
    """

    def __init__(self):
        self.state = defaultdict(dict)

    def apply(self, event: Dict[str, Any]):
        et = event["type"]
        pid = event["patient_id"]
        dtype = event["directive_type"]

        if et in ("AdvanceDirectiveAdded", "AdvanceDirectiveUpdated"):
            self.state[pid][dtype] = {
                "details": event.get("details"),
                "timestamp": event["timestamp"],
                "by": event.get("added_by") or event.get("updated_by"),
                "notes": event.get("notes"),
            }

        elif et == "AdvanceDirectiveRevoked":
            if dtype in self.state[pid]:
                del self.state[pid][dtype]


class AdvanceDirectiveHistoryProjection:
    """
    patient_id → list of all directive events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] in (
            "AdvanceDirectiveAdded",
            "AdvanceDirectiveUpdated",
            "AdvanceDirectiveRevoked",
        ):
            pid = event["patient_id"]
            self.state[pid].append(event)
