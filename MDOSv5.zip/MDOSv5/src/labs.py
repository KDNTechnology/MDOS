# labs.py
# MDOS Lab Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

LAB_SCHEMAS = {
    "LabOrdered": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "ordered_by",
            "test_name",
        ],
        "optional": ["priority", "notes"],
    },

    "LabResultReceived": {
        "required": [
            "encounter_id",
            "patient_id",
            "timestamp",
            "resulted_by",
            "test_name",
            "result_value",
        ],
        "optional": ["units", "reference_range", "notes"],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestLabResultsProjection:
    """
    patient_id → { test_name → latest result }
    """

    def __init__(self):
        self.state = defaultdict(dict)

    def apply(self, event: Dict[str, Any]):
        if event.get("type") != "LabResultReceived":
            return

        pid = event["patient_id"]
        test = event["test_name"]

        self.state[pid][test] = {
            "result_value": event["result_value"],
            "units": event.get("units"),
            "reference_range": event.get("reference_range"),
            "timestamp": event["timestamp"],
            "resulted_by": event["resulted_by"],
        }


class LabHistoryProjection:
    """
    patient_id → list of all lab events
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event.get("type") in ("LabOrdered", "LabResultReceived"):
            pid = event["patient_id"]
            self.state[pid].append(event)
