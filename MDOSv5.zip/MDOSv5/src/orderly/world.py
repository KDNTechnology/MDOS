# src/orderly/world.py
# Omega World — crash‑proof, constitutional, event‑sourced runtime

import importlib
import pkgutil
from pathlib import Path
from typing import Dict, Any

from .event_log import append_event, rebuild_events


# ---------------------------------------------------------------------------
# Projection Registry
# ---------------------------------------------------------------------------

class ProjectionRegistry:
    """
    Holds all projections. Each projection has an .apply(event) method
    and exposes a .state dictionary.
    Crash‑proof: projection errors are contained.
    """

    def __init__(self):
        self._projections = {}

    def add(self, name: str, projection: Any):
        self._projections[name] = projection

    def apply_all(self, event: Dict[str, Any]):
        for name, proj in self._projections.items():
            try:
                proj.apply(event)
            except Exception as e:
                print(f"[PROJECTION ERROR] {name}: {e}")

    def get_state(self) -> Dict[str, Any]:
        return {name: proj.state for name, proj in self._projections.items()}

    def get(self, name: str):
        return self._projections.get(name)


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

class Router:
    """
    Maps event types → modules that care about them.
    Crash‑proof: routing is simple and cannot fail.
    """

    def __init__(self):
        self.routes = set()

    def register_event_type(self, event_type: str):
        self.routes.add(event_type)

    def route(self, event: Dict[str, Any]):
        return {"status": "accepted", "event_type": event["type"]}

    def get_event_types(self):
        return sorted(list(self.routes))


# ---------------------------------------------------------------------------
# World Runtime
# ---------------------------------------------------------------------------

class World:
    """
    The sovereign runtime.
    Crash‑proof: no module can kill the OS.
    """

    def __init__(self):
        self.schemas: Dict[str, Any] = {}
        self.projections = ProjectionRegistry()
        self.router = Router()
        self.modules = []  # loaded modules for buddy command registry

    # ------------------------------------------------------------------
    # Registration helpers (called by modules)
    # ------------------------------------------------------------------

    def add_projection(self, name: str, projection: Any):
        try:
            self.projections.add(name, projection)
        except Exception as e:
            print(f"[ADD PROJECTION ERROR] {name}: {e}")

    def route_event_type(self, event_type: str):
        try:
            self.router.register_event_type(event_type)
        except Exception as e:
            print(f"[ROUTE EVENT TYPE ERROR] {event_type}: {e}")

    def add_schema(self, name: str, schema: Dict[str, Any]):
        try:
            self.schemas[name] = schema
        except Exception as e:
            print(f"[ADD SCHEMA ERROR] {name}: {e}")

    def get_projection(self, name: str):
        return self.projections.get(name)

    # ------------------------------------------------------------------
    # Module loading (core + modules/)
    # ------------------------------------------------------------------

    def _load_from_path(self, pkg_path: Path, pkg_name: str):
        """
        Load all modules in a given package path.
        Crash‑proof: bad modules are quarantined.
        """
        for module_info in pkgutil.iter_modules([str(pkg_path)]):
            name = module_info.name

            if name in (
                "world",
                "event_log",
                "terminal_ui",
                "html_renderer",
                "__pycache__",
            ):
                continue

            # Crash‑proof import
            try:
                module = importlib.import_module(f"{pkg_name}.{name}")
            except Exception as e:
                print("\n==============================")
                print(" MODULE FAILED TO LOAD")
                print(f" Name: {name}")
                print(f" Error: {e}")
                print("==============================\n")
                raise

            # Crash‑proof registration
            try:
                if hasattr(module, "register"):
                    module.register(self)
            except Exception as e:
                print(f"[MODULE REGISTER ERROR] {name}: {e}")

            # Store module for buddy command registry
            self.modules.append(module)

    def load_modules(self):
        """
        Auto‑discover modules in:
          - src/orderly/ (core)
          - src/orderly/modules/ (clinical)
        Crash‑proof: no module can stop loading.
        """
        base_path = Path(__file__).parent
        base_pkg = __package__  # "orderly"

        # Load core modules
        self._load_from_path(base_path, base_pkg)

        # Load clinical modules
        modules_path = base_path / "modules"
        if modules_path.exists():
            self._load_from_path(modules_path, f"{base_pkg}.modules")

    # ------------------------------------------------------------------
    # Event handling
    # ------------------------------------------------------------------

    def append(self, event: Dict[str, Any]):
        """
        Append event to cryptographic log and apply to projections.
        Crash‑proof: projection errors are contained.
        """
        try:
            stored = append_event(event)
        except Exception as e:
            print(f"[EVENT LOG ERROR] {e}")
            return None

        self.projections.apply_all(stored)
        return stored

    def rebuild(self):
        """
        Replay the entire event log from scratch.
        Crash‑proof: projections reset safely.
        """
        try:
            events = rebuild_events()
        except Exception as e:
            print(f"[REBUILD LOG ERROR] {e}")
            events = []

        # Reset projections
        self.projections = ProjectionRegistry()

        # Re‑register modules
        try:
            self.load_modules()
        except Exception as e:
            print(f"[MODULE RELOAD ERROR] {e}")

        # Replay events
        for event in events:
            try:
                self.projections.apply_all(event)
            except Exception as e:
                print(f"[REPLAY ERROR] {e}")


# ---------------------------------------------------------------------------
# Boot function
# ---------------------------------------------------------------------------

def boot_world():
    """
    Creates a world, loads modules, replays events, and returns it.
    Crash‑proof: world always boots.
    """
    world = World()

    try:
        world.load_modules()
    except Exception as e:
        print(f"[BOOT LOAD ERROR] {e}")

    try:
        world.rebuild()
    except Exception as e:
        print(f"[BOOT REBUILD ERROR] {e}")

    return world
