# gastrointestinal_assessment.py
# MDOS Gastrointestinal Assessment Module
# Pure schemas + projections. No interpretation.

from typing import Dict, Any
from collections import defaultdict


# ---------------------------------------------------------------------------
# Event Schemas
# ---------------------------------------------------------------------------

GASTROINTESTINAL_ASSESSMENT_SCHEMAS = {
    "GastrointestinalAssessmentPerformed": {
        "required": [
            "patient_id",
            "timestamp",
            "performed_by",
        ],
        "optional": [
            "abdominal_inspection",      # distention, scars, visible peristalsis
            "bowel_sounds",              # normal, hypoactive, hyperactive, absent
            "tenderness",                # RUQ, LUQ, RLQ, LLQ, diffuse
            "rebound_tenderness",
            "guarding",
            "masses",
            "hepatomegaly",
            "splenomegaly",
            "nausea",
            "vomiting",
            "diarrhea",
            "constipation",
            "notes",
        ],
    },
}


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------

class LatestGastrointestinalAssessmentProjection:
    """
    patient_id → latest GI assessment snapshot
    """

    def __init__(self):
        self.state = {}

    def apply(self, event: Dict[str, Any]):
        if event["type"] != "GastrointestinalAssessmentPerformed":
            return

        pid = event["patient_id"]

        snapshot = {
            "timestamp": event["timestamp"],
            "performed_by": event["performed_by"],
        }

        for key in [
            "abdominal_inspection",
            "bowel_sounds",
            "tenderness",
            "rebound_tenderness",
            "guarding",
            "masses",
            "hepatomegaly",
            "splenomegaly",
            "nausea",
            "vomiting",
            "diarrhea",
            "constipation",
            "notes",
        ]:
            if key in event:
                snapshot[key] = event[key]

        self.state[pid] = snapshot


class GastrointestinalAssessmentHistoryProjection:
    """
    patient_id → list of GI assessments
    """

    def __init__(self):
        self.state = defaultdict(list)

    def apply(self, event: Dict[str, Any]):
        if event["type"] == "GastrointestinalAssessmentPerformed":
            pid = event["patient_id"]
            self.state[pid].append(event)
