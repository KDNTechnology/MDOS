# src/notifications.py

class Notifications:
    """
    Notification organ.
    Provides unified hooks for:
      - email
      - SMS
      - Discord/Slack webhooks
      - system alerts

    Actual delivery is intentionally minimal and pluggable.
    """

    def notify(self, message, channel="console"):
        if channel == "console":
            print(f"[NOTIFY] {message}")
        elif channel == "machine":
            self._machine_event("notification", message)
        else:
            print(f"[NOTIFY:{channel}] {message} (delivery not implemented)")

    def notify_error(self, message):
        print(f"[ERROR] {message}")
        self._machine_event("error_notification", message)

    def notify_success(self, message):
        print(f"[SUCCESS] {message}")
        self._machine_event("success_notification", message)
