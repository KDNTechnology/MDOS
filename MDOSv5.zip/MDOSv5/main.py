# main.py
# Omega / MDOS entrypoint

from src.orderly.world import boot_world
from src.orderly.buddy_mdos import run as run_buddy

def main():
    world = boot_world()
    run_buddy(world)

if __name__ == "__main__":
    main()
