# src/orderly/buddy_mdos.py

import json

def print_banner():
    print("\nMDOS — Medical Doctor Open Systems")
    print("Constitutional Interface (REPL)")
    print("--------------------------------")
    print("Commands:")
    print("  state        → show all projections")
    print("  reload       → rebuild projections from event log")
    print("  template     → print an example event structure")
    print("  quit         → exit\n")
    print('Enter events as JSON objects (must include "type" and "patient_id")\n')

def example_event():
    return {
        "type": "VitalsRecorded",
        "patient_id": "P123",
        "encounter_id": "E456",
        "timestamp": "2026-02-14T20:00:00Z",
        "recorded_by": "nurse_01",
        "heart_rate": 72,
        "blood_pressure": "120/80",
        "consent_given": True,
    }

def run(world):
    """
    world is the Omega world object:
      - world.projections  → ProjectionRegistry
      - world.rebuild()    → rebuild projections from events
      - world.router       → Router instance
    """
    print_banner()

    # initial rebuild (world boot already handled event log)
    try:
        world.rebuild()
        print("Projections ready")
    except Exception as e:
        print(f"[REBUILD FAILED] {e}")

    projections = world.projections
    router = world.router

    while True:
        try:
            raw = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting.")
            break

        if not raw:
            continue

        cmd = raw.lower()
        if cmd in ("quit", "exit", "q"):
            print("Goodbye.")
            break

        if cmd == "state":
            try:
                state = projections.get_state()
                print(json.dumps(state, indent=2, default=str))
            except Exception as e:
                print(f"[STATE ERROR] {e}")
            continue

        if cmd == "reload":
            try:
                world.rebuild()
                print("Projections rebuilt.")
            except Exception as e:
                print(f"[RELOAD ERROR] {e}")
            continue

        if cmd == "template":
            print(json.dumps(example_event(), indent=2))
            continue

        # Parse event
        try:
            event = json.loads(raw)
        except json.JSONDecodeError as e:
            print(f"[!] Invalid JSON: {e}")
            continue

        if not isinstance(event, dict):
            print("[!] Event must be JSON object")
            continue

        # Constitutional consent gate
        etype = event.get("type", "")
        if not (etype.startswith(("Consent", "System")) or event.get("consent_given", False)):
            print('[!] Consent missing — MDOS Oath violation. Add "consent_given": true')
            continue

        # Route
        try:
            result = router.route(event)
            print(json.dumps(result, indent=2, default=str))
        except Exception as e:
            print(f"[ROUTER ERROR] {e}")
