# src/orderly/terminal_ui.py

import os
from datetime import datetime

def clear():
    os.system("cls" if os.name == "nt" else "clear")

def render_terminal(world):
    clear()

    state = world.projections.get_state()
    patients = state.get("patient_directory", {})

    print("-----------------------------------------")
    print(" MDOS Patient System")
    print(f" Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("-----------------------------------------")
    print(f" Patients: {len(patients)}")

    last_event = None
    for proj in state.values():
        if isinstance(proj, dict) and "last_event" in proj:
            last_event = proj["last_event"]

    print(f" Last Event: {last_event}")
    print("-----------------------------------------")
    print(" Type 'projection <patient_id>' to open HTML view")
    print("-----------------------------------------")
